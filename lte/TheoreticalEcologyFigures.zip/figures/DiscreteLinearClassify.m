delta=(0:500)/100; tau1=sqrt(4*delta); tau2=-tau1;
yaxis=(0:500)/50-5; 
axis on;
plot(delta,tau1,'k',delta,tau2,'k',delta,0*tau2,'k:',-delta,0*tau2,'k:',0*delta,yaxis,'k:');  
xlim([-2 2]); ylim([-3 3]); 
hold on; 
delta=((0:200)-100)/100; tau1=1+delta; tau2=-tau1; 
plot(delta,tau1,'k',delta,tau2,'k'); 
px=[1 1]; py=[-2 2]; plot(px,py,'k'); 

title('Stability of fixed points, X(t+1)=F(X(t))','Fontsize',16');
xlabel('Determinant \Delta','Fontsize',16);
ylabel('Trace T','Fontsize',16);

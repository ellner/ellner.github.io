fit1=function(x) {1.25*exp(-0.05*((x-48)^2))}
fit2=function(x) {exp(-0.05*((x-32)^2))}

px=20+(0:400)/10; 
par(cex.axis=1.4,cex.lab=1.4,mar=c(5,6,5,5));
plot(px,fit1(px),type="l",lty=1,xlab="Switch date",ylab="Fitness (eggs/female)",lwd=2); 
points(px,fit2(px),type="l",lty=1,col="green",lwd=2); 
legend(22,1.2,c("Few fish","Many fish"),col=c("black","green"),lty=1,lwd=2,cex=1.25); 

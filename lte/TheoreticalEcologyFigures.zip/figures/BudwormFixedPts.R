f1=function(x) {x/(1+x^2)}
f2=function(x) {r*(1-x/k)}

par(cex.lab=1.5,cex.axis=1.5,mar=c(5,6,5,5)); 
plot(f1,0,10,type="l",lty=1,lwd=2,ylab="Rate functions"); 

x=0:100/10
r=1; k=10; 
points(x,f2(x),type="l",lwd=2,lty=2); 

r=0.43; k=10; 
points(x,f2(x),type="l",lwd=2,lty=2); 

r=0.562; k=10; 
points(x,f2(x),type="l",lwd=2,lty=2); 


X=read.table("e:/classes/theoreticalecology/figures/PhillipiData.txt");
X=as.matrix(X); 

par(cex.axis=1.5,cex.lab=1.5,xaxs="i",yaxs="i"); 
plot(X[-1,1],X[-1,2],xlab="Mean Average Rainfall (cm)",ylab="Germination Fraction(%)",
type="p",pch=16,ylim=c(0,75),xlim=c(0,14),cex=2);
points(X[1,1],X[1,2],pch=16,cex=2,col="grey60"); 

fit1=lm(X[,2]~X[,1]); abline(fit1,lwd=2);  

fit2=lm(X[-1,2]~X[-1,1]); abline(fit2,lwd=2,col="grey60");  

title("Phillipi (1993) data on L. lasiocarpum"); 

text(8,20,"r^2=0.34, p=0.047",cex=2); 
text(8,12,"r^2=0.13, p=0.28 ",col="grey60",cex=2); 



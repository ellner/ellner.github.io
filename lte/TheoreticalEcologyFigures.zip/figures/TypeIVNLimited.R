setwd("e:\\classes\\theoreticalecology\\figures"); 
X=read.csv("TypeIVNLimited.csv"); 
X1=X[1:7,]; X2=X[8:14,]; 
par(cex.lab=1.5,cex.axis=1.5); 
matplot(X[1:7,2],cbind(X1[1:7,3],X2[1:7,3]),type="o",lty=1,
pch=c(16,1),col=c("blue","green3"),lwd=2,cex=2,xlab="Cells per ml",
ylab="Rotifer population growth rate r");
title(c("Brachionus feeding on N-limited Chlamy",
"Experiments by Aldo Barreiro Felpeto")) 

legend("bottom",legend=c("With medium","Without medium"), 
lty=1,pch=c(16,1),col=c("blue","green3"),lwd=2,cex=2,bty="n"); 
abline(h=0,lty=2); 


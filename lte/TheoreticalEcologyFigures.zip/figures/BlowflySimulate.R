#simulate blowfly model as age-structured
sj=0.91^(1/157); sa=exp(-0.027); 
ba=function(a) 0.85*a*exp(-a/600)

jt=numeric(157); at=5000; 

nsteps=2500; 
avals=numeric(nsteps); avals[1]=at; evals=rep(0,nsteps);    
for(j in 2:2500) {
	et=ba(at);
	at=jt[157]+sa*at; 
	jt[2:157]=sj*jt[1:156]; 
 	jt[1]=et;
	avals[j]=at; evals[j]=et; 
}
tvals=(0:(nsteps-1))/10; 
win.graph(6,5); 
par(cex.lab=1.5,cex.axis=1.35,mar=c(5,6,5,4)); 
matplot(tvals,cbind(avals,10*evals),type="l",lty=c(1,2),lwd=2,
xlab="time (days)", ylab="Adults (solid), Eggs/d (dash)")  
# savePlot(file="e:\\classes\\theoreticalecology\\figures\\BlowflySimulate", type="ps"); 

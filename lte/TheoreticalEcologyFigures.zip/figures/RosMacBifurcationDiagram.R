par(cex.lab=1.35,cex.axis=1.35,xaxs="i",yaxs="i"); 
plot(NULL,xlim=c(1,10),ylim=c(-4,5),xlab="K",ylab="Predator population"); 

Kvals=seq(0,10,by=0.01); xstar=3; ystar=(1+xstar)*(1-xstar/Kvals); 
points(Kvals,ystar,type="l",lty=2,lwd=2); 

Ks=seq(3,7,by=0.01); ys=(1+xstar)*(1-xstar/Ks); 
points(Ks,ys,type="l",lty=1,lwd=3); 

abline(h=0,lty=2,lwd=2)
points(c(1,3),c(0,0),lty=1,type="l",lwd=3);

px=seq(7,10,by=0.01); y0=(1+xstar)*(1-xstar/px);  
points(px,y0+0.9*sqrt(px-7),type="l",lty=1,lwd=3); 
points(px,y0-0.9*sqrt(px-7),type="l",lty=1,lwd=3); 

title("Bifurcation diagram of Rosenzweig-MacArthur"); 
r<-1.35;
h<-matrix(0,46,1);
p<-matrix(0,46,1);
h[1]<-1.05*r*log(r)/(r-1);
p[1]<-log(r);
for (i in 1:45) {
	h[i+1]<-r*h[i]*exp(-p[i])
	p[i+1]<-h[i]*(1-exp(-p[i]))
  }
par(mfrow=c(2,1),cex.axis=1.35,cex.lab=1.35);
plot(1:46,h,pch="H",type="b",xlab="Generation",ylab="H & P Density"); 
points(1:46,p,pch="P",type="b");
plot(1:46,log10(p),pch="P",type="b",xlab="Generation",ylab="log10 H & P Density");
points(1:46,log10(h),pch="H",type="b");

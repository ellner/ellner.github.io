par(mar=c(5,6,4,2),cex.axis=1.5,cex.lab=1.5);
x<-c(0:100)/100; 
s<- -0.2;
y1<-0*x; 
y2<- s-0.1*x-x^2; 
y3<- s-3*x^2+3*x;
y4<- s-x^2+3*x;
matplot(x,cbind(y1,y2,y3,y4),type="l", lwd=2,
lty=c(2,1,1,1),cex=2,xlab="Germination fraction H",
ylab="Long-term growth rate rho",fty="s");
 

text(0.6,-0.4,"1",cex=1.75);
text(0.6,0.7,"3",cex=1.75);
text(0.6,1.5,"2",cex=1.75);

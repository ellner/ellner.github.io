px=seq(-5,5,.1); 
par(xaxt="n",yaxt="n",bty="n"); 
py=px; plot(px,py,type="p",col="white",xlab=" ",ylab=""); 
abline(h=0); abline(v=0); 
text(4,-0.65,"Real part",cex=1.25);
text(-1.1,4.7,"Imaginary",cex=1.25);
text(-0.8,4.3,"part",cex=1.25);

jv=c(-5:-1,1:5) 
for(j in jv) {
text(j,-0.3,j,cex=1.25)  
px=c(j,j); py=c(-0.1,0.1); points(px,py,type="l");
}

for(j in jv) {
text(-0.3,j,j,,cex=1.25)  
py=c(j,j); px=c(-0.1,0.1); points(px,py,type="l");
}

points(3,2,cex=1.5,pch=16); 
text(3,2.3,"3+2i",cex=1.25)
points(c(0,3),c(0,2),type="l")

text(2.2,0.5,expression(theta),cex=1.5)

theta=seq(0,0.588,0.01);
points(2.5*cos(theta),2.5*sin(theta),type="l",lty=1); 

arrows(2.5*cos(.5),2.5*sin(.5),2.5*cos(.588),2.5*sin(.588))

2
px=c(0:98); 
py1=2*px*(1-px/88); py2=50*px/(35+px);  
par(xaxs="i",yaxs="i",tcl=0,cex.axis=2,cex.lab=1.75,mar=c(5,6,5,5)); 
matplot(px,cbind(py1,py2),ylab="Rate functions f(x),g(x)",
type="l", lwd=c(2,1),lty=1,col="black",axes=FALSE,xlab=""); 
axis(2, c(-30,0,50),c("","0",""))
abline(h=0,lty=1); text(2,-3,"0",cex=2); 
text(50,-3,"Prey density x",cex=1.7); 
text(86,-3,"K",cex=1.6); 
#box() 

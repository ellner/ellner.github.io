logisticmap=function(n,r) r*n*(1-n) 
map2=function(n,r) logisticmap(logisticmap(n,r),r); 

nt=seq(0,1,0.001); 


par(mfrow=c(3,2),xaxs="i",yaxs="i",cex.axis=1,cex.lab=1.5); 

r=2.8; 
plot(nt,logisticmap(nt,r),type="l",lty=1,xlab="n(t)",ylab="n(t+1)",ylim=c(0,1));
abline(0,1); title("First iterate, r=2.9"); 
plot(nt,map2(nt,r),type="l",lty=1,xlab="n(t)",ylab="n(t+2)",ylim=c(0,1));
abline(0,1); title("Second iterate, r=2.8");

r=3; 
plot(nt,logisticmap(nt,r),type="l",lty=1,xlab="n(t)",ylab="n(t+1)",ylim=c(0,1));
abline(0,1); title("First iterate, r=3"); 
plot(nt,map2(nt,r),type="l",lty=1,xlab="n(t)",ylab="n(t+2)",ylim=c(0,1));
abline(0,1); title("Second iterate, r=3"); 

r=3.2; 
plot(nt,logisticmap(nt,r),type="l",lty=1,xlab="n(t)",ylab="n(t+1)",ylim=c(0,1));
abline(0,1); title("First iterate, r=3.2"); 
plot(nt,map2(nt,r),type="l",lty=1,xlab="n(t)",ylab="n(t+2)",ylim=c(0,1));
abline(0,1); title("Second iterate, r=3.2"); 
 
 
V=2; c=3; p=seq(0,1,0.01); 
D=(1-p)*V/2; E=p*(V/2-c)+(1-p)*V;

par(cex.axis=1.5,cex.lab=1.5,mar=c(5,6,5,5),xaxs="i",yaxs="i"); 
matplot(p,cbind(D,E),col=c("blue","red"), type="l",lty=1,lwd=2,
xlab="Frequency of Escalate, p",ylab="Payoffs for D(blue), E(red)")

px=rep(V/(2*c),2); py=c(-3,(1-px[1])*V/2); points(px,py,type="l",lty=2); 
mtext("p*",side=1,at=px[1],cex=1.5); 
v =matrix(runif(200*500),200,250)>0.5;
r=0.7+0.65*v; nt=apply(r,2,cumprod); 

#nt=matrix(1,200,250);
#for(j in 2:200) {
#	nt[j,]=nt[j-1,]*r[j,];
#}

par(cex.axis=1.5,cex.lab=1.5,mar=c(5,6,5,5)); 
matplot(1:200,log(nt),type="l",lty=1,col="black",xlab="Time t",ylab="Log (population size)"); 
points(1:200,log(apply(nt,1,mean)),type="l",lty=1,lwd=3); 
points(1:200,apply(log(nt),1,mean),type="l",lty=1,lwd=3); 

taus=c(0.6,5,5.9,4.1); 
xdot=numeric(2); 

bf=function(t,y,parms) {
	A=y[1]; J=y[2];
	xdot[1]= J - parms[1]*A
	xdot[2]= parms[2]*A*exp(-A) - J
	return(list(xdot))
}



q=1; delta=0.25; parms=c(delta,q); 

y0=c(log(q/delta),delta*log(q/delta))*exp(0.05*rnorm(2)); 
out=lsoda(y0,times=c(0:5000)/10,func=bf,parms=parms); 
plot(out[,2],out[,3],type="l");

for(j in 1:5) {
y0=c(log(q/delta),delta*log(q/delta))*exp(0.05*rnorm(2)); 
out=lsoda(y0,times=c(0:5000)/10,func=bf,parms=parms); 
points(out[,2],out[,3],type="l");
}

points(log(q/delta),delta*log(q/delta),pch=1,cex=3); 

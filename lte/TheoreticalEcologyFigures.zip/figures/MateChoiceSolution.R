v=seq(-2,2,by=0.1); b=0.2; 
nv=length(v); 

p.reject=pnorm(v); 
f.accept=function(x) {x*dnorm(x,0,1)}
v.accept=rep(0,nv); 
for(j in 1:nv) {
v.accept[j]=integrate(f.accept,lower=v[j],upper=6)$value
}
rhs=v.accept+p.reject*(1-b)*v; 
matplot(v,cbind(v,rhs),col="black",type="l",lwd=2,lty=c(2,1),
xlab="Expected Reward V",ylab="Payoff"); 

title("Q~Normal(0,1), b=0.2") 
points(x=c(0.81,0.81),y=c(-3,0.81),type="l",lty=4); 
points(0.81,0.81,pch=16,cex=2); 

par(cex.axis=1.35,cex.lab=1.35); 
plot(NULL,xlim=c(0,1.25),ylim=c(-2,0.5),xlab="u",ylab="v");
abline(v=0); abline(h=0); 

points(0,0,pch=17,cex=2); points(1,0,pch=2,cex=2); 
arrows(1, 0, 0.8,-0.2,lwd=2);
arrows(1,0,1.2,0.2,lwd=2); 
arrows(0.8,0.2,1,0,lwd=2);
arrows(1.2,-0.2,1,0,lwd=2); 

points(c(1,1),c(0,-2),col="blue",lty=2,type="l"); 
points(c(0,1),c(0,-2),col="blue",lty=2,type="l"); 

arrows(0.5,-1,0.4,-0.8,col="red",lwd=2,angle=20); 
arrows(0.5,-1,0.4,-0.55,col="black",lwd=2,angle=20); 
arrows(0.5,0.2,0.5,-0.2,col="black",lwd=2,angle=20); 
arrows(1.1,-0.5,0.9,-0.5,col="black",lwd=2,angle=20); 




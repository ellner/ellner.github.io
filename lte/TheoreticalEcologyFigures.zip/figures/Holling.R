px=c(0:150)/100; 
py1=0.85*px; py2=px/(.35+px); py3=(px^3)/(.5^3+px^3); 
  
par(xaxs="i",yaxs="i",tcl=0,cex.axis=1.35,cex.lab=1.5,mar=c(5,6,5,5)); 
matplot(px,cbind(py1,py2,py3),ylab="Predator functional response",
type="l", lwd=c(2,2,1),lty=c(1,2,1),col="black",axes=FALSE,
xlab="Prey density"); 
axis(2, c(0,1.5),c("0",""))
abline(h=0,lty=1); 
mtext("0",side=1,at=0.01,outer=F, cex=1.35);
text(locator(),"(I)",cex=2,vfont=c("serif","plain"));  
text(locator(),"(II)",vfont=c("serif","plain"),cex=2); 
text(locator(),"(III)",vfont=c("serif","plain"),cex=2); 
savePlot(file="e:\\classes\\theoreticalecology\\figures\\Holling.ps"); 




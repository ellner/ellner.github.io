win.graph(10,5); 
par(mfrow=c(1,2));
nb<-as.matrix(read.table("e:\\classes\\theoreticalecology\\figures\\NB.out"));
hosts<-nb[,1]; pars<-nb[,2]; ngrid<-sqrt(length(hosts));
x<-c(1:ngrid); y<-c(1:ngrid);
image(x,y,matrix(sqrt(hosts),ngrid,ngrid),col=grey(1-(0:100)/100)); title(main='hosts');
image(x,y,matrix(sqrt(pars),ngrid,ngrid),col=grey(1-(0:100)/100)); title(main='parasites');
savePlot(file="e:\\classes\\theoreticalecology\\figures\\PlotNBLattice",type="ps"); 

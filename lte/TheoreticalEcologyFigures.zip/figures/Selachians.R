year=seq(1914,1923,by=1);
selach=c(11.9,21.4,22.1,21.2,36.4,27.3,16.0,15.9,14.8,10.7); 
plot(year,selach,xlab="Year",ylab="Percent", type="o", 
pch=16,cex=1.5,cex.lab=1.5,cex.axis=1.5); 
title(main="Fraction of selachians (D'Ancona 1926)")
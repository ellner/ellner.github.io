require(fields); 

get.LENNS.EXEC<- function(){
LENNS.EXEC="c:\\lenns\\exec";
return( LENNS.EXEC)
}

"add.netfit.model" <-
function(fita, fitb)
{
	if(fita$d != fitb$d)
		stop(" mismatch in dimensions of two models")
	d <- fita$d
	ka <- fita$k
	kb <- fitb$k
	temp.a <- summary.netfit(fita, F)
	temp.b <- summary.netfit(fitb, F)
	temp <- list()
	class(temp) <- "netfit"
	temp$np <- fita$np + fitb$np - 1
	temp$d <- d
	temp$k <- ka + kb
	theta <- c(temp.a$beta[1] + temp.b$beta[1], temp.a$beta[2:(ka + 1)],
		temp.b$beta[2:(kb + 1)], temp.a$mu, temp.b$mu, c(t(rbind(temp.a$
		gamma, temp.b$gamma))))
	temp$theta <- theta
	temp$xm <- rep(0, d)
	temp$xsd <- rep(1, d)
	temp$ym <- 0
	temp$ysd <- 1
	temp
}
"coef.nnreg" <-
function(out, model = out$best.model)
{
	fit <- out$model[[model]]
	d <- fit$d
	if(is.null(fit$xm)) {
		fit$xm <- rep(0, fit$d)
		fit$xsd <- 1
	}
	if(is.null(fit$ym)) {
		fit$ym <- 0
		fit$ysd <- 1
	}
	k <- fit$k
	theta <- fit$theta
	beta <- theta[1:(k + 1)]
	mu <- theta[(1:k) + k + 1]
	gamma <- matrix(theta[(1:(d * k)) + 2 * k + 1], ncol = d, nrow = k,
		byrow = T)
	dimnames(gamma) <- list(paste("gamma", 1:k, sep = ""), NULL)
	names(beta) <- paste("beta", 0:k, sep = "")
	names(mu) <- paste("mu", 1:k, sep = "")
	return(model, x.center = fit$xm, x.scale = fit$xsd, y.center = fit$
		ym, y.scale = fit$ysd, d, k, beta, mu, gamma)
}
"d.squasher.nnreg" <-
function(u)
{
	au <- abs(u)
	su <- ifelse(u < 0, -1, 1)
	N <- (u * (1 + 0.5 * au))
	D <- (2 + au + 0.5 * au * au)
	((1 + au) * D - N * (su + u))/(D * D)
}

"lle.default" <-
function (jac, lags = NA, nprod = c(5, 10, 20, 40, 80), skip = NA, 
    statevector = F, verbose = F) 
{
    if (!is.na(skip)) 
        jac <- as.matrix(jac[, -1 * skip])
    n <- nrow(jac)
    m <- length(nprod)
    if (!is.na(lags[1])) {
             hold <- jac
      # fill up a matrix with zeroes
                jac <- matrix(0, ncol = max(lags), nrow = n)
      #replace nonzero columns with columns of the passed jacobian.
                jac[, lags] <- hold
    }
    if (!is.na(nprod[1])) {
        temp1 <- matrix(nrow = n, ncol = m)
        temp2 <- matrix(nrow = n, ncol = m)
        temp3 <- matrix(nrow = n, ncol = m)
        dimnames(temp1) <- list(NULL, paste(format(nprod), "steps"))
        dimnames(temp2) <- list(NULL, paste(format(nprod), "steps"))
        for (k in 1:length(nprod)) {
            if (nprod[k] < n) 
                temp <- make.lle(jac, nprod[k], statevector = statevector, 
                  verbose = verbose)
            temp1[1:(n - nprod[k] + 1), k] <- temp[, 1]
            temp2[1:(n - nprod[k] + 1), k] <- temp[, 2]
            temp3[1:(n - nprod[k] + 1), k] <- temp[, 3]
        }
    }
    else {
        temp1 <- NA
        temp2 <- NA
        temp3 <- NA
    }
    glb <- make.lle(jac, -1, statevector = statevector,  
        verbose = verbose)[, 2]
    temp <- list(local.svd = temp1, local.qr = temp2, local.11 = temp3, 
        nprod = nprod, glb = glb)
    class(temp) <- "lle"
    temp
}
"lle.nlar" <-
function (obj, model = NA, nprod = c(5, 10, 20, 40, 80), verbose = F,  ...) 
{
    statevector <- F
    if (is.na(model)) {
        model <- obj$fit$best.model
    }
    jac <- predict(obj$fit, derivative = 1, model = model, ...)
    lle.default(jac, lags = obj$lags, skip = obj$skip, nprod = nprod,
 verbose = verbose)
}
"lle" <-
function (x, ...) 
UseMethod("lle")
"make.lags" <-
function(x, lags, cov = NA, nobs = 3500)
{
        x <- as.matrix(x)
        xd <- ncol(x)
        m <- length(lags)
        N <- min(nobs, nrow(x) - max(lags))
        n <- min(nobs, N)
        if(N > nobs)
                warning(" series length truncated to\ndefault length in make.lags")
        start <- max(lags) + 1
        temp <- matrix(0, ncol = xd * (length(lags)), nrow = n)
        for(k in 1:length(lags)) {
                a <- start - lags[k]
                b <- a + n - 1
                temp[, (1:xd) + (k - 1) * xd] <- x[(a:b),  ]
        }
        a <- start
        b <- a + n - 1
        if(xd == 1)
                lab <- format(paste("lag", rep(lags, rep(xd, 
length(lags))),
                        sep = ""))
        else lab <- format(paste( rep(1:xd, length(lags)), "lag", 
rep(lags,
                        rep(xd, length(lags))), sep = ""))
        dimnames(temp) <- list(NULL, lab)
        skip <- NA
        if(!is.na(cov[1])) {
                cov <- as.matrix(cov)
                temp <- cbind(temp, cov[a:b,  ])
                cat(a, b)
                skip <- (1:ncol(cov)) + m * xd
        }
        if(xd == 1)
                y <- c(x[a:b])
        else y <- x[a:b,  ]
        list(x = temp, y = y, nvar = m, lags = lags, skip = skip, start = 
a,
                end = b)
}
"make.lle" <-
function (jac, nprod, statevector = F, verbose = T,
lle.executable=paste(get.LENNS.EXEC(),"lle.exe",sep="/")) 
{
    nc <- ncol(jac)
    if (statevector) {
        state <- 1
        emd <- sqrt(nc)
        test <- emd - round(emd)
        if (test != 0) 
            cat("Stop, no. of col of jac is not a perfect \nsquare", 
                fill = T)
    }
    else {
        state <- 0
        emd <- nc
    }
    write(c(nc, emd, nprod, state), "lle.par")
    write(t(jac), "temp.lle", ncol = nc)

cmd<- paste(lle.executable," < temp.lle > lle.out")
    if (verbose) 
        cat(" running in the shell", cmd, fill = T)
#system( cmd)
 shell( cmd, intern=T, invisible=T)
    if (verbose) 
        cat(" reading in matrix of LLE's", fill = T)
    temp <- matrix(scan("lle.out"), ncol = 3, byrow = T)
    temp
}
"netfit.reformat.greedy" <-
function(model)
{
	nm <- length(model)
	temp <- list(1:nm)
	temp[[1]] <- model[[1]]
	if(nm > 1) {
		for(jj in 2:nm) {
			temp[[jj]] <- add.netfit.model(temp[[jj - 1]], model[[
				jj]])
		}
	}
	temp
}
"nlar" <-
function (Y, lags, cov = NA, method = "nnreg", ...) 
{
    out <- list()
    if (is.function(method)) 
        method <- substitute(method)
    class(out) <- "nlar"
    out$call <- match.call()
    temp <- make.lags(Y, lags, cov)
    out$lags <- temp$lags
    out$skip <- temp$skip
    out$lags <- temp$lags
    out$start <- temp$start
    out$end <- temp$end
    out$method <- method
    out$cov <- cov
    out$Y <- Y
    out$fit <- get(method)(temp$x, temp$y, ...)
    out$best.model <- out$fit$best.model
    out
}
"nnet.scale" <-
function(x)
{
	x <- x - min(x)
	x/max(x)
}
"nnreg" <-
function (x, y, k1, k2, start, ngrind = 250, ntries = 100, npol = 20, 
    tol1 = 1e-06, tol2 = 1e-09, itmax1 = 250, itmax2 = 10000, 
    derivative = F, fin = "nnreg.par", fout = "nnreg.out", run = T, 
    just.setup = F, just.read = F, fitted.values = F, all.fits = F, 
    greedy = F, seed, fast = T, na.rm = T, nnreg.executable = paste(get.LENNS.EXEC(), 
        "nnreg.exe", sep = "/")) 
{
    lags <- NA
    call <- match.call()
    y <- c(y)
    if (missing(seed)) 
        seed <- as.integer(runif(1) * 125000)
    x <- as.matrix(x)
    d <- ncol(x)
#
# if start values/model supplied of course use the number of hidden units
# according to the starting model
#
        if (!missing(start)) {
            k1<- start$k
        }
    if (missing(k2)) {
        k2 <- k1
    }
    
    ind <- !is.na(y)
    if (sum(ind) < length(ind)) {
        cat("Some NA's were found and removed from data set", fill = T)
        y <- y[ind]
        x <- x[ind, ]
    }
    if (length(dimnames(x)) != 2) {
        dimnames(x) <- list(format(1:nrow(x)), paste("X", 1:d, 
            sep = ""))
    }
    if (length(dimnames(x)[[1]]) == 0) {
        dimnames(x)[[1]] <- format(1:nrow(x))
    }
    if (length(dimnames(x)[[2]]) == 0) {
        dimnames(x)[[2]] <- paste("X", 1:d, sep = "")
    }
    jac.list <- NA
    if (fast) {
        ngrind <- 100
        ntries <- 50
        npol <- 5
        tol1 <- 0.01
        tol2 <- 1e-06
    }
    if (!just.read) {
        write(t(cbind(y, x)), "nnreg.dat", ncol = 1)
        if (!missing(start)) {
            ngrind <- -1
        }
        if (all.fits) 
            iprint <- 1
        else iprint <- 0
        if (greedy) 
            igreed <- 1
        else igreed <- 0
        write(c("nnreg.dat", "nnreg.sum"), fin, ncol = 1)
        temp <- c(length(y), ncol(x), ngrind, ntries, npol, iprint, 
            igreed, seed, tol1, tol2, itmax1, itmax2, k1, k2)
        write(temp, fin, ncol = 1, append = T)
        write(deparse(match.call()), fin, ncol = 1, append = T)
        if (ngrind < 0) {
            if (class(start)[1] == "nnreg") 
                start <- start$model[[start$best.model]]$theta
            if (class(start)[1] == "netfit") 
                start <- start$theta
            write(unlist(start), "nnreg.str", ncol = 1)
        }
        if (just.setup) {
            cat("Input file and data files have been constructed for nnreg", 
                fill = T)
            cat("Run nnreg in the UNIX shell or in DOS by:", 
                fill = T)
            cmd <- paste(nnreg.executable, "< ", fin, "  > ", 
                fout, sep = "")
            cat(cmd, fill = T)
            return()
        }
        if (run == T) {
            cmd <- paste(nnreg.executable, " <", fin, "  > ", 
                fout, sep = "")
            cat("Running nnreg in the shell", fill = T)
            cat(" with ", cmd, fill = T)
            #system(cmd)
 shell( cmd, intern=T, invisible =T)
        }
    }
    if (!just.setup) {
        temp <- list()
        class(temp) <- c("nnreg")
        cat("Reading in results from ", fout, fill = T)
        temp$model <- read.nnreg(fout)
        if (greedy) 
            temp$model <- netfit.reformat.greedy(temp$model)
        temp$summary <- scan("nnreg.sum", what = "a", sep = "\n")
        class(temp$summary) <- "textfile"
        nfits <- length(temp$model)
        cat(nfits, " models read in from ", fout, fill = T)
        temp$fitted.values <- matrix(NA, ncol = nfits, nrow = length(y))
        if (!all.fits | fitted.values) {
            for (k in 1:nfits) {
                temp$fitted.values[, k] <- predict(temp$model[[k]], 
                  x)
            }
            temp$residuals <- y - temp$fitted.values
        }
        temp$call <- call
        temp$x <- x
        temp$y <- y
        temp$n <- length(y)
        temp$nfits <- nfits
        temp$lags <- lags
        temp$seed <- seed
        hold <- summary(temp, noprint = T)
        temp$best.model <- order(hold[, 6])[1]
        return(temp)
    }
    else {
        invisible()
    }
}
"nnregCI" <-
function (fit, model = fit$best.model, ngrind = 250, ntries = 100, 
    npol = 20, clevel = 0.95, cut1 = NA, cut2 = NA, nfits = 500, 
    tol1 = 1e-06, tol2 = 1e-09, itmax1 = 250, itmax2 = 10000, 
    fdata, fout = "nnci.out", fin = "nnci.par", seed, just.read = F, 
    just.setup = F, nnregci.executable = paste(get.LENNS.EXEC(), 
"nnregci.exe", 
        sep = "/")) 
{
    call <- match.call()
    if (!just.read) {
        if (missing(seed)) 
            seed <- as.integer(runif(1) * 125000)
        y <- fit$y
        x <- as.matrix(fit$x)
        k <- fit$model[[model]]$k
        d <- ncol(x)
        rms <- fit$model[[model]]$rms
        np <- fit$model[[model]]$np
        if (missing(fdata)) {
            fdata <- "nnci.dat"
            write(t(cbind(y, x)), fdata, ncol = 1)
        }
        if (is.na(cut1)) 
            cut1 <- rms * sqrt((1 + qf(clevel, np, length(y) - 
                np) * (np/(length(y) - np))))
        if (is.na(cut2)) 
            cut2 <- cut1 - 0.2 * (cut1 - rms)
        write(c(fdata, "nnci.sum"), fin, ncol = 1)
        temp <- c(length(y), ncol(x), ngrind, ntries, npol, rms, 
            cut1, cut2, nfits, seed, tol1, tol2, itmax1, itmax2, 
            k)
        write(temp, fin, ncol = 1, append = T)
        write(deparse(call), fin, append = T)
        if (just.setup) {
            cat("files are now set up to run nnregci in the shell", 
                fill = T)
            stop()
        }
        cmd <- paste(nnregci.executable, " < ", fin, " > ", fout, 
            sep = "")
        cat("Running nnreg in the shell", fill = T)
        cat("Using ", cmd, fill = T)
#        system(cmd)
         shell( cmd, intern=T, invisible=T)
    }
    temp <- list()
    class(temp) <- c("nnreg")
    cat("Reading in results from output file", fill = T)
    temp$model <- read.nnreg(fout)
    temp$summary <- scan("nnci.sum", what = "a", sep = "\n")
    class(temp$summary) <- "textfile"
    nfits <- length(temp$model)
    cat(nfits, " models read in from ", fout, fill = T)
    temp$call <- call
    temp$x <- x
    temp$y <- y
    temp$n <- length(y)
    temp$nfits <- nfits
    temp$seed <- seed
    return(temp)
}
"plot.lle" <- function(out,type="qr",...) 
{
temp<-  out[[paste("local.",type,sep="")]]
    bplot(temp, pos = log10(out$nprod), labels = format(out$nprod), 
        xlab = "Number of Steps",ylab=paste( type,"LLE estimates"), ...)
    yline(out$glb, col=2)
}
 
"plot.nlar" <-
function (out, ...)
{
    main.title <- deparse(out$call)
    plot(out$fit, main = main.title, ...)
}

"plot.nnreg" <-
function(out, model = out$best.model, main = NA, digits = 4, 
graphics.reset = T,
	...)
{
	old.par <- par("mfrow", "oma")
	if(graphics.reset) {
		on.exit(par(old.par))
		par(xpd = T)
	}
	if(model == out$best.model & (ncol(out$residuals) > 1)) {
		cat("Note: there is more than one model in the nnreg output object",
			fill = T)
	}
	set.panel(2, 2, T)
	temp <- summary(out, noprint = T)
	plot(out$fitted.values[, model], out$y, ylab = "Y", xlab = 
		"predicted values", bty = "n")
	abline(0, 1)
	hold <- par("usr")
	text(hold[1], hold[4], paste(" R**2 =", format(round(100 * cor(out$
		fitted.values[, model], out$y)^2, 2)), "%", sep = ""), cex = 
		0.8, adj = 0)
	plot(out$fitted.values[, model], out$residuals[, model], ylab = 
		"residuals", xlab = "predicted values", bty = "n")
	yline(0)
	hold <- par("usr")
	text(hold[1], hold[4], paste(" RMSE =", format(signif(temp[model, 4],
		digits))), cex = 0.8, adj = 0)
	if(ncol(out$residuals) > 1) {
		matplot(temp[, 2], temp[, 5:6], ylab = "GCV (1) and GCV2 (2)",
			xlab = "Number of Parameters", bty = "n", col = 1)
		xline(temp[model, 2])
		hold <- par("usr")
		text(temp[model, 2], hold[4], paste(" # par =", format(temp[
			model, 2]), "\n # units =", format(temp[model, 1])),
			cex = 0.8, adj = 0)
		title("GCV and GCV2", cex = 0.6)
	}
	else {
		matplot(rep(temp[, 2], 2), temp[, 5:6], ylab = 
			"GCV (1) and GCV2 (2)", xlab = "Number of Parameters",
			bty = "n", col = 1, type = "n")
		text(rep(temp[, 2], 2), temp[, 5:6], labels = c("1", "2"))
		xline(temp[model, 2])
		hold <- par("usr")
		text(temp[model, 2], hold[4], paste(" # par =", format(temp[
			model, 2]), "\n # units =", format(temp[model, 1])),
			cex = 0.8, adj = 0)
		title("GCV and GCV2", cex = 0.6)
	}
	matplot(temp[, 2], temp[, 4], ylab = "RMSE", xlab = 
		"Number of Parameters", pch = "*", bty = "n")
	title("Root Mean Squared Error", cex = 0.6)
	if(is.na(main))
		mtext(deparse(out$call), cex = 1.3, outer = T, line = -2)
	else mtext(main, cex = 1.3, outer = T, line = -2)
	invisible()
}
"predict.netfit" <-
function(fit, x, derivative = 0, type = "full")
{
	nx <- nrow(x)
	d <- fit$d
	if(is.null(fit$xm)) {
		fit$xm <- rep(0, fit$d)
		fit$xsd <- 1
	}
	if(is.null(fit$ym)) {
		fit$ym <- 0
		fit$ysd <- 1
	}
	if(d != ncol(x))
		stop(" columns of X not equal to d!")
	# standardize the X's 
	#
	# I am reforming x becuase this seemed to give problems if x was 
	# a matrix with attributes
	#
	u <- (matrix(c(x), nrow = nx, ncol = d) - matrix(fit$xm, ncol = d,
		nrow = nx, byrow = T))/matrix(fit$xsd, ncol = d, nrow = nx,
		byrow = T)
	k <- fit$k
	theta <- fit$theta
	beta <- theta[1:(k + 1)]
	mu <- theta[(1:k) + k + 1]
	gamma <- matrix(theta[(1:(d * k)) + 2 * k + 1], ncol = d, nrow = k,
		byrow = T)
	pu <- cbind(rep(1, nx), u) %*% t(cbind(mu, gamma))
	if(derivative == 0) {
		# find predicted values and transform to original scale
		if(type == "full") {
			yhat <- fit$ysd * (squasher.nnreg(pu) %*% beta[2:(
				k + 1)] + beta[1]) + fit$ym
		}
		if(type == "terms") {
			temp <- dim(pu)
			yhat <- list(u = pu, yhat = fit$ysd * (squasher.nnreg(
				pu)) * matrix(beta[2:(k + 1)], nrow = temp[
				1], ncol = temp[2], byrow = T), constant = fit$
				ysd * beta[1] + fit$ym)
		}
		return(yhat)
	}
	else {
		if(type == "terms")
			stop("derviative not available for individual\nhidden units"
				)
		jac <- fit$ysd * (d.squasher.nnreg(pu) %*% (gamma/matrix(fit$
			xsd, ncol = d, nrow = k, byrow = T) * matrix(beta[
			2:(k + 1)], ncol = d, nrow = k)))
		return(jac)
	}
}
"predict.nnreg" <-
function(out, x = out$x, model = NA, derivative = 0, type = "full")
{
	if(is.na(model)) {
		model <- out$best.model
	}
	if(model == out$best.model & out$nfits > 1) {
		warning("Using the selected model from nnreg fit")
	}
	fit <- out$model[[model]]
	predict(fit, x, derivative, type = type)
}
"print.lle" <-
function(obj, digits = 5,type="qr")
{
        cat("estimated global exponent", obj$glb, fill = T)
        cat("summary of ", type," estimate", fill = T)
        temp <- t(stats(obj[[paste("local.",type,sep="")]]))
        temp <- signif(temp, digits)
        temp <- temp[, c(1, 2, 3, 5, 6, 7)]
        print(temp)
}
  "print.nlar" <-
function( obj,...){
 
 
cat( "call to nlar:", fill=T)
print(obj$call)
cat( fill=T)
print( obj$fit,...)
 
}
"print.nnreg" <-
function(out, noprint = F, digits = 4)
{
	n <- out$n
	nfits <- out$nfits
	temp <- matrix(0, ncol = 6, nrow = nfits)
	for(j in 1:nfits) {
		fit <- out$model[[j]]
		temp[j, 1] <- fit$k
		ss <- sum((out$y - predict(fit, out$x))^2)
		temp[j, 2] <- fit$np
		temp[j, 3] <- n - fit$np
		temp[j, 4] <- signif(sqrt(ss/temp[j, 3]), digits)
		temp[j, 5] <- signif((ss/n)/(1 - temp[j, 2]/n)^2, digits)
		temp[j, 6] <- signif((ss/n)/(1 - (2 * temp[j, 2])/n)^2, digits)
	}
	dimnames(temp) <- list(format(1:nfits), c("# hidden units", "DF model",
		"DF residuals", "Root MSE", "GCV", "GCV cost=2"))
	if(!noprint) {
		cat("call to nnreg :", fill = T)
		print(out$call)
		print(temp)
		cat("see the component summary in the output list for", fill = 
			T)
		cat("more details of the fitting process", fill = T)
	}
	else {
		return(temp)
	}
}
"print.textfile" <-
function( obj) { cat( obj, fill=T)}
"read.nnreg" <-
function(fname = "nnreg.out")
{
	temp <- scan(fname)
	ntemp <- length(temp)
	out <- list()
	#	cmd <- paste("grep '#' ", fname, " > nnreg.temp")
	#	unix(cmd)
	#	out$summary <- c(scan("nnreg.temp", what = "a", sep = "\n"), 
	#scan("nnreg.summary", what = "a", sep = "\n"))
	i <- 1
	loc <- 0
	out <- list()
	while(loc < ntemp) {
		#print(" start model loc=")
		#print(loc)
		if(loc + 3 > ntemp) break
		d <- temp[1 + loc]
		k <- temp[2 + loc]
		rms <- temp[3 + loc]
		loc <- loc + 3
		if(loc + 2 * (d + 1) > ntemp)
			break
		xm <- temp[(1:d) + loc]
		loc <- loc + d
		xsd <- temp[(1:d) + loc]
		loc <- loc + d
		ym <- temp[loc + 1]
		ysd <- temp[loc + 2]
		loc <- loc + 2
		np <- 1 + k * (d + 2)
		if(loc + np > ntemp)
			break
		theta <- temp[loc + (1:np)]
		loc <- loc + np
		out[[i]] <- list(d = d, k = k, xm = xm, ym = ym, xsd = xsd,
			ysd = ysd, np = np, theta = theta, rms = rms)
		class(out[[i]]) <- "netfit"
		i <- i + 1
	}
	if(loc != length(temp))
		cat("incomplete information in ", fname, " output file", fill
			 = T)
	out
}
"rossler" <-
c(13.826, 16.413, 8.1707, 0.88173, -2.5314, -5.415, -7.1653, 
-7.6376, -6.1774, -2.4068, 2.0182, 6.2966, 9.297, 9.7725, 7.7158, 
3.7258, -1.6392, -6.6156, -10.829, -12.194, -10.592, -6.1298, 
-0.32746, 6.4896, 12.138, 14.974, 12.21, 3.7752, -1.0058, -6.1122, 
-10.115, -11.793, -10.848, -6.8813, -0.64638, 6.5914, 12.403, 
15.084, 12.115, 3.6094, -1.4525, -6.279, -9.8714, -11.167, -10.071, 
-6.0666, 0.019344, 6.5585, 11.623, 14.146, 12.209, 5.7051, -0.47912, 
-6.4347, -11.717, -13.716, -12.649, -8.3252, -1.2223, 6.6123, 
13.429, 17.022, 8.3991, 0.44922, -2.2292, -4.5175, -5.8484, -5.8398, 
-4.0409, -1.4656, 1.9429, 4.8234, 6.9691, 7.3595, 6.0718, 3.0257, 
-0.57546, -4.4023, -7.8788, -9.1549, -8.5422, -5.6285, -0.94519, 
4.5998, 8.6367, 11.475, 11.559, 8.0757, 2.7841, -3.5202, -9.0835, 
-13.331, -14.844, -12.005, -6.1196, 1.6026, 9.5696, 16.2, 16.559, 
1.3599, -0.98001, -2.6895, -3.4291, -3.7632, -2.5448, -1.204, 
0.92898, 2.4575, 3.9103, 4.2027, 3.4988, 2.2926, 0.23494, -1.8592, 
-4.1555, -5.5449, -5.527, -3.9898, -1.4592, 1.5902, 4.4671, 6.3222, 
6.9337, 5.7583, 2.9283, -0.61991, -4.6623, -7.909, -9.1904, -8.2506, 
-4.9154, -0.47599, 4.6305, 8.9992, 11.097, 10.483, 7.447, 2.245, 
-4.1747, -10.041, -13.589, -13.291, -9.8029, -3.8433, 3.6612, 
10.592, 15.662, 14.699, 3.1999, -0.64648, -4.313, -6.5809, -7.7348, 
-7.1925, -4.454, -0.53033, 3.786, 7.5461, 9.4733, 9.2123, 6.73, 
2.3877, -2.9176, -7.8203, -11.212, -12.155, -9.7872, -4.8518, 
2.2185, 8.8347, 13.612, 14.756, 8.6635, 2.0699, -3.1771, -7.7709, 
-10.682, -11.474, -9.1558, -4.3307, 2.2203, 8.5422, 12.799, 13.759, 
9.8831, 3.5659, -2.2851, -7.6938, -11.642, -13.041, -11.303, 
-6.2759, 0.42482, 7.8575, 13.606, 16.158, 8.6109, 1.0792, -2.8096, 
-6.1421, -8.1113, -8.346, -6.3772, -2.9253, 2.0682, 6.8656, 9.8261, 
11.142, 9.4526, 4.6118, -1.4303, -7.7247, -12.367, -14.153, -12.519, 
-7.6245, -0.73513, 7.5834, 14.415, 17.493, 4.7145, -0.45901, 
-2.7568, -3.8855, -4.3139, -4.096, -2.3194, 0.051935, 2.1057, 
4.3209, 5.954, 5.8802, 4.0393, 1.0416, -2.3546, -5.5642, -7.6049, 
-7.5785, -5.7753, -2.318, 1.9138, 6.0432, 8.9169, 9.4746, 7.9286, 
3.8023, -1.1831, -6.2518, -10.238, -11.807, -10.744, -6.6594, 
-0.83291, 5.5698, 11.362, 14.494, 12.935, 5.4291, -0.48404, -6.0058, 
-10.133, -11.91, -11.09, -7.3402, -1.5426, 5.1339, 11.613, 15.108, 
12.958, 3.8971, -1.3056, -6.4179, -9.7016, -10.769, -8.9979, 
-4.9287, 0.99026, 6.8715, 11.195, 13.2, 11.359, 6.4498, -0.25887, 
-6.7851, -11.985, -14.236, -13.8, -9.7239, -2.6149, 5.5433, 13.395, 
17.565, 7.3493, -0.20408, -1.8093, -2.8792, -3.0381, -2.6721, 
-1.6046, -0.33693, 1.3245, 3.0132, 3.9434, 3.9707, 2.4806, 0.51869, 
-1.4843, -3.6351, -4.6123, -4.4262, -3.3517, -1.3536, 1.3214, 
3.9676, 5.7077, 5.4769, 4.3356, 2.1365, -0.6267, -3.7848, -6.1154, 
-7.1139, -6.2042, -3.7986, -0.26902, 3.7052, 6.984, 8.0107, 7.9821, 
5.5554, 1.6669, -2.8261, -7.1972, -10.106, -10.565, -8.1132, 
-3.5139, 2.104, 7.7076, 12.043, 13.227, 10.077, 4.4406, -1.6912, 
-7.4148, -12.308, -14.037, -12.702, -7.8967, -0.37375, 7.6443, 
14.384, 17.428, 4.8386, -0.49197, -3.0792, -4.5407, -5.4248, 
-4.7369, -2.8794, -0.25639, 2.6401, 5.3593, 7.3278, 7.6238, 5.1813, 
1.2006, -2.9898, -6.7874, -8.7033, -8.8349, -7.1795, -3.379, 
1.7683, 6.6936, 9.9471, 10.905, 9.2622, 5.3305, -0.14749, -5.9188, 
-10.73, -12.797, -12.04, -8.3665, -2.1953, 4.7371, 11.362, 15.614, 
13.78, 2.9364, -1.5513, -5.6995, -8.3018, -8.5426, -6.9417, -3.7013, 
1.3918, 5.6464, 9.3027)
"rossler.state" <-
structure(c(13.826, 16.413, 8.1707, 0.88173, -2.5314, -5.415, 
-7.1653, -7.6376, -6.1774, -2.4068, 2.0182, 6.2966, 9.297, 9.7725, 
7.7158, 3.7258, -1.6392, -6.6156, -10.829, -12.194, -10.592, 
-6.1298, -0.32746, 6.4896, 12.138, 14.974, 12.21, 3.7752, -1.0058, 
-6.1122, -10.115, -11.793, -10.848, -6.8813, -0.64638, 6.5914, 
12.403, 15.084, 12.115, 3.6094, -1.4525, -6.279, -9.8714, -11.167, 
-10.071, -6.0666, 0.019344, 6.5585, 11.623, 14.146, 12.209, 5.7051, 
-0.47912, -6.4347, -11.717, -13.716, -12.649, -8.3252, -1.2223, 
6.6123, 13.429, 17.022, 8.3991, 0.44922, -2.2292, -4.5175, -5.8484, 
-5.8398, -4.0409, -1.4656, 1.9429, 4.8234, 6.9691, 7.3595, 6.0718, 
3.0257, -0.57546, -4.4023, -7.8788, -9.1549, -8.5422, -5.6285, 
-0.94519, 4.5998, 8.6367, 11.475, 11.559, 8.0757, 2.7841, -3.5202, 
-9.0835, -13.331, -14.844, -12.005, -6.1196, 1.6026, 9.5696, 
16.2, 16.559, 1.3599, -0.98001, -2.6895, -3.4291, -3.7632, -2.5448, 
-1.204, 0.92898, 2.4575, 3.9103, 4.2027, 3.4988, 2.2926, 0.23494, 
-1.8592, -4.1555, -5.5449, -5.527, -3.9898, -1.4592, 1.5902, 
4.4671, 6.3222, 6.9337, 5.7583, 2.9283, -0.61991, -4.6623, -7.909, 
-9.1904, -8.2506, -4.9154, -0.47599, 4.6305, 8.9992, 11.097, 
10.483, 7.447, 2.245, -4.1747, -10.041, -13.589, -13.291, -9.8029, 
-3.8433, 3.6612, 10.592, 15.662, 14.699, 3.1999, -0.64648, -4.313, 
-6.5809, -7.7348, -7.1925, -4.454, -0.53033, 3.786, 7.5461, 9.4733, 
9.2123, 6.73, 2.3877, -2.9176, -7.8203, -11.212, -12.155, -9.7872, 
-4.8518, 2.2185, 8.8347, 13.612, 14.756, 8.6635, 2.0699, -3.1771, 
-7.7709, -10.682, -11.474, -9.1558, -4.3307, 2.2203, 8.5422, 
12.799, 13.759, 9.8831, 3.5659, -2.2851, -7.6938, -11.642, -13.041, 
-11.303, -6.2759, 0.42482, 7.8575, 13.606, 16.158, 8.6109, 1.0792, 
-2.8096, -6.1421, -8.1113, -8.346, -6.3772, -2.9253, 2.0682, 
6.8656, 9.8261, 11.142, 9.4526, 4.6118, -1.4303, -7.7247, -12.367, 
-14.153, -12.519, -7.6245, -0.73513, 7.5834, 14.415, 17.493, 
4.7145, -0.45901, -2.7568, -3.8855, -4.3139, -4.096, -2.3194, 
0.051935, 2.1057, 4.3209, 5.954, 5.8802, 4.0393, 1.0416, -2.3546, 
-5.5642, -7.6049, -7.5785, -5.7753, -2.318, 1.9138, 6.0432, 8.9169, 
9.4746, 7.9286, 3.8023, -1.1831, -6.2518, -10.238, -11.807, -10.744, 
-6.6594, -0.83291, 5.5698, 11.362, 14.494, 12.935, 5.4291, -0.48404, 
-6.0058, -10.133, -11.91, -11.09, -7.3402, -1.5426, 5.1339, 11.613, 
15.108, 12.958, 3.8971, -1.3056, -6.4179, -9.7016, -10.769, -8.9979, 
-4.9287, 0.99026, 6.8715, 11.195, 13.2, 11.359, 6.4498, -0.25887, 
-6.7851, -11.985, -14.236, -13.8, -9.7239, -2.6149, 5.5433, 13.395, 
17.565, 7.3493, -0.20408, -1.8093, -2.8792, -3.0381, -2.6721, 
-1.6046, -0.33693, 1.3245, 3.0132, 3.9434, 3.9707, 2.4806, 0.51869, 
-1.4843, -3.6351, -4.6123, -4.4262, -3.3517, -1.3536, 1.3214, 
3.9676, 5.7077, 5.4769, 4.3356, 2.1365, -0.6267, -3.7848, -6.1154, 
-7.1139, -6.2042, -3.7986, -0.26902, 3.7052, 6.984, 8.0107, 7.9821, 
5.5554, 1.6669, -2.8261, -7.1972, -10.106, -10.565, -8.1132, 
-3.5139, 2.104, 7.7076, 12.043, 13.227, 10.077, 4.4406, -1.6912, 
-7.4148, -12.308, -14.037, -12.702, -7.8967, -0.37375, 7.6443, 
14.384, 17.428, 4.8386, -0.49197, -3.0792, -4.5407, -5.4248, 
-4.7369, -2.8794, -0.25639, 2.6401, 5.3593, 7.3278, 7.6238, 5.1813, 
1.2006, -2.9898, -6.7874, -8.7033, -8.8349, -7.1795, -3.379, 
1.7683, 6.6936, 9.9471, 10.905, 9.2622, 5.3305, -0.14749, -5.9188, 
-10.73, -12.797, -12.04, -8.3665, -2.1953, 4.7371, 11.362, 15.614, 
13.78, 2.9364, -1.5513, -5.6995, -8.3018, -8.5426, -6.9417, -3.7013, 
1.3918, 5.6464, 9.3027, -9.7337, -2.4359, 4.534, 6.7532, 6.8208, 
5.2711, 2.3431, -1.3503, -5.1818, -7.9125, -8.678, -7.1535, -3.6178, 
1.1977, 5.9599, 9.4885, 10.806, 9.4629, 5.6204, -0.068862, -6.1598, 
-11.103, -13.69, -13.16, -9.297, -2.8287, 4.415, 8.8619, 10.186, 
9.1047, 5.5762, 0.27154, -5.7108, -10.906, -13.776, -13.355, 
-9.3524, -2.7993, 4.4968, 8.7635, 9.9556, 8.7102, 5.1126, -0.057304, 
-5.6924, -10.402, -12.858, -12.203, -8.3149, -2.0757, 4.8686, 
9.9237, 12.021, 11.189, 7.2459, 1.0504, -5.9411, -11.981, -15.486, 
-15.307, -11.222, -3.9923, 3.3324, 5.1467, 4.9749, 3.5589, 1.1538, 
-1.8173, -4.6279, -6.4907, -6.9312, -5.5882, -2.9327, 0.63957, 
4.1949, 6.9391, 8.1511, 7.4744, 4.8682, 0.80322, -3.8241, -7.9217, 
-10.302, -10.159, -7.4233, -2.6778, 3.2069, 8.6167, 12.196, 12.973, 
10.658, 5.5441, -1.5166, -8.7971, -14.298, -16.646, -15.026, 
-9.4705, -1.1762, 3.1694, 3.3995, 2.7037, 1.3275, -0.47006, -2.2178, 
-3.4304, -3.8257, -3.1793, -1.7739, 0.31275, 2.4459, 4.1187, 
5.0983, 5.0382, 3.8615, 1.5168, -1.2717, -3.9281, -5.6938, -6.1636, 
-5.088, -2.5723, 0.70181, 4.1229, 6.7464, 7.9509, 7.1999, 4.4951, 
0.39527, -4.2329, -8.0783, -10.142, -9.9113, -7.0653, -2.3081, 
3.3001, 8.3616, 11.621, 12.103, 9.3468, 3.7895, -3.0601, -9.5249, 
-13.912, -15.085, -12.508, -6.543, 1.2077, 6.026, 7.0445, 6.3058, 
3.9286, 0.44651, -3.4654, -6.8963, -8.8058, -8.6262, -6.2909, 
-2.2761, 2.4663, 6.8903, 9.9073, 10.551, 8.572, 4.2124, -1.5768, 
-7.5468, -12.03, -13.733, -11.897, -6.8758, 0.11895, 6.6545, 
9.7526, 10.215, 8.1161, 3.8391, -1.7254, -7.3022, -11.46, -12.947, 
-11.116, -6.3435, 0.22258, 6.7167, 10.729, 11.863, 10.092, 5.7599, 
-0.33734, -6.8694, -12.145, -14.75, -13.78, -9.1338, -1.9746, 
5.0329, 7.4662, 7.6069, 5.8489, 2.5336, -1.636, -5.6795, -8.6357, 
-9.6455, -8.0936, -4.2859, 0.92428, 6.4989, 10.781, 12.608, 11.232, 
6.826, 0.26453, -6.8379, -12.712, -15.99, -15.492, -10.938, -3.2723, 
3.3254, 4.1859, 3.6771, 2.1833, 0.12208, -2.1026, -4.0833, -4.9789, 
-4.7242, -3.3979, -0.98531, 2.1006, 4.9175, 6.6741, 6.9318, 5.4039, 
2.3768, -1.4606, -5.1766, -7.7324, -8.5053, -7.0215, -3.5936, 
1.0061, 5.6722, 9.3255, 10.78, 9.6787, 6.0803, 0.69858, -5.2435, 
-10.303, -13.069, -12.949, -9.4839, -3.339, 3.7749, 8.9278, 10.875, 
10.036, 6.5566, 1.1965, -4.8697, -10.156, -13.333, -13.478, -10.122, 
-3.7803, 3.6023, 8.2137, 9.4471, 8.136, 4.5045, -0.56234, -5.9157, 
-10.108, -11.897, -10.796, -6.8512, -0.96074, 5.5584, 10.761, 
13.309, 12.535, 8.5354, 2.2379, -5.0589, -11.765, -16.035, -16.563, 
-12.88, -5.6325, 1.8873, 3.0105, 2.6934, 1.654, 0.22946, -1.2425, 
-2.4938, -3.1776, -3.2197, -2.3632, -0.71939, 1.3021, 3.1244, 
4.185, 4.2079, 3.1825, 1.2178, -1.1133, -3.2547, -4.7353, -5.2053, 
-4.2236, -1.9561, 0.90375, 3.5665, 5.5732, 6.3814, 5.7471, 3.5772, 
0.39569, -3.0951, -6.0402, -7.5908, -7.3065, -5.0716, -1.4857, 
2.6471, 6.4744, 8.9641, 9.3622, 7.4508, 3.4498, -1.8139, -7.0424, 
-10.706, -11.902, -10.245, -5.823, 0.47161, 6.7615, 11.118, 12.715, 
11.26, 6.8942, 0.42757, -6.6216, -12.653, -15.902, -15.24, -10.639, 
-2.9359, 3.6039, 4.583, 4.0128, 2.3172, -0.14028, -2.8074, -5.0415, 
-6.271, -6.1174, -4.4802, -1.5124, 2.3053, 5.9192, 8.1464, 8.3334, 
6.4545, 2.8249, -1.5709, -5.9292, -9.1746, -10.369, -8.9691, 
-5.2372, -0.099735, 5.1985, 9.5487, 11.692, 11.032, 7.4944, 1.8172, 
-4.6402, -10.458, -14.128, -14.633, -11.457, -5.1983, 2.5458, 
6.8219, 7.6944, 6.4121, 3.203, -0.9876, -5.1942, -8.4143, -9.7547, 
-8.7009, -5.4228, 0.22485, 3.6947, 23.264, 1.2215, 0.050022, 
0.015121, 0.011985, 0.011501, 0.012226, 0.015257, 0.022294, 0.039846, 
0.083713, 0.17455, 0.1756, 0.058874, 0.019938, 0.012541, 0.0099838, 
0.0095605, 0.010928, 0.01277, 0.01799, 0.036865, 0.13795, 1.2233, 
10.697, 3.6463, 0.12315, 0.017804, 0.011877, 0.012037, 0.016205, 
0.016902, 0.017689, 0.036442, 0.15178, 1.4128, 12.892, 3.6619, 
0.12122, 0.018009, 0.012083, 0.011954, 0.014033, 0.014233, 0.018273, 
0.037116, 0.1325, 0.92724, 5.9441, 3.535, 0.15629, 0.0186, 0.012981, 
0.022926, 0.097724, 0.16557, 0.03948, 0.037904, 0.17975, 3.1832, 
30.835, 1.3564, 0.055819, 0.015937, 0.013016, 0.012706, 0.013892, 
0.016794, 0.022613, 0.034658, 0.051354, 0.068937, 0.060243, 0.035222, 
0.020586, 0.014406, 0.011576, 0.010533, 0.010791, 0.012483, 0.017062, 
0.029702, 0.065216, 0.1956, 0.62255, 0.67862, 0.10968, 0.0183, 
0.011025, 0.0092002, 0.013103, 0.044117, 0.044049, 0.022802, 
0.058804, 0.53062, 18.253, 8.4194, 0.24537, 0.023907, 0.01536, 
0.014566, 0.015506, 0.017393, 0.020786, 0.025828, 0.030812, 0.03519, 
0.032907, 0.026847, 0.021409, 0.01718, 0.0145, 0.012866, 0.012841, 
0.013962, 0.016798, 0.021911, 0.031423, 0.047429, 0.058936, 0.054669, 
0.033577, 0.020612, 0.014313, 0.011537, 0.010589, 0.010927, 0.012975, 
0.017953, 0.029701, 0.068077, 0.19121, 0.47064, 0.39179, 0.064663, 
0.016598, 0.010807, 0.010206, 0.018341, 0.039339, 0.023222, 0.025838, 
0.079471, 0.71105, 12.687, 7.6357, 0.23357, 0.022298, 0.012958, 
0.011495, 0.011673, 0.01336, 0.017698, 0.027782, 0.052045, 0.10609, 
0.16807, 0.12379, 0.039451, 0.017144, 0.011708, 0.0097461, 0.0095892, 
0.011098, 0.013357, 0.021738, 0.055462, 0.29087, 2.9655, 10.567, 
0.95349, 0.041181, 0.013963, 0.011272, 0.01219, 0.014283, 0.014487, 
0.022189, 0.053431, 0.22954, 1.6165, 5.657, 1.1149, 0.04787, 
0.013995, 0.011095, 0.014536, 0.031108, 0.029414, 0.019891, 0.043977, 
0.23846, 3.332, 21.182, 1.2589, 0.050521, 0.014954, 0.011608, 
0.011065, 0.012027, 0.014848, 0.021961, 0.041995, 0.10139, 0.26728, 
0.46621, 0.16079, 0.024695, 0.012307, 0.0096538, 0.011653, 0.030741, 
0.042301, 0.020839, 0.040941, 0.24491, 5.8194, 25.486, 0.7141, 
0.038476, 0.015528, 0.013878, 0.014154, 0.015558, 0.019289, 0.024388, 
0.031843, 0.042865, 0.049466, 0.038807, 0.024787, 0.017245, 0.013253, 
0.011544, 0.01126, 0.012325, 0.015562, 0.022206, 0.039436, 0.078954, 
0.14626, 0.1515, 0.059809, 0.020807, 0.012914, 0.010106, 0.009211, 
0.0096218, 0.011647, 0.01716, 0.03188, 0.10904, 0.81268, 6.6599, 
4.696, 0.19457, 0.020369, 0.012517, 0.013231, 0.020043, 0.020823, 
0.017372, 0.030665, 0.10758, 0.984, 10.466, 4.4131, 0.14679, 
0.019579, 0.012753, 0.012541, 0.013782, 0.013988, 0.020232, 0.040431, 
0.12691, 0.61392, 2.5302, 1.7052, 0.10376, 0.016129, 0.011511, 
0.018425, 0.096089, 0.30863, 0.095589, 0.036017, 0.15523, 3.1743, 
40.247, 1.2747, 0.055424, 0.017151, 0.015385, 0.015725, 0.016867, 
0.018955, 0.021853, 0.026647, 0.031804, 0.033177, 0.028504, 0.022366, 
0.017817, 0.015033, 0.013696, 0.01368, 0.014813, 0.017223, 0.021237, 
0.029665, 0.041769, 0.04671, 0.038418, 0.027945, 0.019823, 0.015067, 
0.012604, 0.011753, 0.01217, 0.013999, 0.018465, 0.027552, 0.047278, 
0.07636, 0.096288, 0.067206, 0.030075, 0.016683, 0.012041, 0.010162, 
0.0098866, 0.010906, 0.014103, 0.022597, 0.047998, 0.17132, 0.99017, 
2.8741, 0.79574, 0.042472, 0.01335, 0.010523, 0.015463, 0.053428, 
0.085514, 0.026439, 0.042917, 0.25249, 6.0615, 24.472, 0.70554, 
0.038348, 0.015177, 0.013187, 0.013542, 0.015239, 0.018617, 0.025301, 
0.036753, 0.056107, 0.075043, 0.056885, 0.027605, 0.016469, 0.012342, 
0.010641, 0.010435, 0.011502, 0.014449, 0.021536, 0.041303, 0.10192, 
0.26664, 0.39363, 0.16534, 0.028137, 0.013541, 0.010067, 0.0092199, 
0.010547, 0.013035, 0.015692, 0.028739, 0.10292, 0.97481, 15.711, 
5.2047, 0.16175, 0.020389, 0.012669, 0.011403, 0.011857, 0.014248, 
0.020678, 0.035463, 0.079399), .Dim = c(400, 3), .Dimnames = list(
    NULL, c("X", "Y", "Z")))
"squasher.nnreg" <-
function(u)
{
	au <- abs(u)
	(u * (1 + 0.5 * au))/(2 + au + 0.5 * au * au)
}
"summary.lle" <-
function(obj, digits = 5,type="qr")
{
        cat("estimated global exponent", obj$glb, fill = T)
        cat("summary of ", type," estimate", fill = T)
        temp <- t(stats(obj[[paste("local.",type,sep="")]]))
        temp <- signif(temp, digits)
        temp <- temp[, c(1, 2, 3, 5, 6, 7)]
        temp
}
"summary.netfit" <-
function(fit, standardized = F)
{
	d <- fit$d
	k <- fit$k
	theta <- fit$theta
	beta <- theta[1:(k + 1)]
	mu <- theta[(1:k) + k + 1]
	gamma <- matrix(theta[(1:(d * k)) + 2 * k + 1], ncol = d, nrow = k,
		byrow = T)
	if(standardized == F) {
		gamma <- gamma * matrix(1/fit$xsd, ncol = fit$d, nrow = fit$
			k, byrow = T)
		temp <- (gamma * matrix(fit$xm, ncol = fit$d, nrow = fit$k,
			byrow = T)) %*% rep(1, fit$d)
		mu <- mu - c(temp)
		beta <- beta * fit$ysd
		beta[1] <- beta[1] + fit$ym
	}
	list(beta = beta, mu = mu, gamma = gamma, standardized = standardized)
}
"summary.nlar" <-
function( obj,...){
 
 
cat( "call to nlar:", fill=T)
print(obj$call)
cat( fill=T)
summary( obj$fit,...)
 
}
"summary.nnreg" <-
function (out, noprint = F, digits = 4) 
{
    n <- out$n
    nfits <- out$nfits
    temp <- matrix(0, ncol = 6, nrow = nfits)
    for (j in 1:nfits) {
        fit <- out$model[[j]]
        temp[j, 1] <- fit$k
        ss <- sum((out$y - predict(fit, out$x))^2)
        temp[j, 2] <- fit$np
        temp[j, 3] <- n - fit$np
        temp[j, 4] <- signif(sqrt(ss/temp[j, 3]), digits)
        temp[j, 5] <- signif((ss/n)/(1 - temp[j, 2]/n)^2, digits)
        temp[j, 6] <- signif((ss/n)/(1 - (2 * temp[j, 2])/n)^2, 
            digits)
    }
    dimnames(temp) <- list(format(1:nfits), c("# hidden units", 
        "DF model", "DF residuals", "Root MSE", "GCV", "GCV cost=2"))
    if (!noprint) {
        cat("call to nnreg :", fill = T)
        print(out$call)
        print(temp)
        cat("see the component summary in the output list for", 
            fill = T)
        cat("more details of the fitting process", fill = T)
    }
    else {
        return(temp)
    }
}
"surface.nnreg" <-
function(obj, grid.list = NA, extrap = F, graphics.reset = NULL, xlab = 
NULL,
        ylab = NULL, main = NULL, zlab = NULL, zlim = NULL, levels = NULL,
        type = "b", ...)
{
        ## modified so that you can give main, and ylab as arguments
        ## in ... and have them passed correctly
        out.p <- predict.surface(obj, grid.list = grid.list, extrap = extrap)
        if(!is.null(ylab))
                out.p$ylab <- ylab
        if(!is.null(xlab))
                out.p$xlab <- xlab
        if(!is.null(zlab))

               out.p$zlab <- zlab
        if(!is.null(main))
                out.p$main <- main
        ##    else
        ##      out.p$main <- NULL
    plot.surface(out.p, type = type, graphics.reset = graphics.reset,
                levels = levels, zlim = zlim, ...)
        invisible()
}




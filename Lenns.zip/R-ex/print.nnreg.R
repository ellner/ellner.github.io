###--- >>> `print.nnreg' <<<----- Print nnreg fit results

	## alias	 help(print.nnreg)

##___ Examples ___:

nnreg(ozone$x,ozone$y,1,3) -> fit # nnreg fit 
print(fit) # print the summary 
fit # this will too 

## Keywords: 'neural'.



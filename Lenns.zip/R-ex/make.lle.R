###--- >>> `make.lle' <<<----- Calculates global and local Lyapunov exponents

	## alias	 help(make.lle)

##___ Examples ___:

make.lags(rossler.state[1:200,1],c(1,2,3)) -> data  # create 
# 3-d time delay vector model of the x variable of rossler system. 
nnreg(data$x,data$y,5,5) -> fit # fit time series model using nnreg. 
predict(fit,fit$x,derivative=1) -> jac # calculate Jacobian matrix 
make.lle(jac,-1) -> rossler.le  # LE of Rossler data 

make.lle(jac, nprod=c( 5,10))-> out
 

## Keywords: 'ts'.



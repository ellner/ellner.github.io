###--- >>> `plot.nnreg' <<<----- Diagnoistic and summary plots of a neural net regression object

	## alias	 help(plot.nnreg)

##___ Examples ___:

nnreg(ozone$x,ozone$y,1,2) -> fit # fitting a surface to ozone  
# measurements, from 1 to 2 hidden units 
plot(fit) # plots fit and residuals 
nnreg(as.matrix(BD[,1:4]),BD[,5],1,5) -> fit # fitting DNA strand 
# displacement amplification surface to various buffer compositions 
plot(fit) # plots fit and residuals 

## Keywords: 'hplot'.



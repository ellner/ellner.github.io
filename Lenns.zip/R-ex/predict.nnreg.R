###--- >>> `predict.nnreg' <<<----- Evaluation of neural net surface.

	## alias	 help(predict.nnreg)

##___ Examples ___:

nnreg(ozone$x,ozone$y,1,2) -> fit           # nnreg fit 
cbind(seq(87,89,,10),seq(40,42,,10)) -> x   # new x matrix 
predict(fit,x) -> out                       # evaluate fit at x 

## Keywords: 'neural'.



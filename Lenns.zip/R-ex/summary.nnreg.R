###--- >>> `summary.nnreg' <<<----- Summary for neural net regression

	## alias	 help(summary.nnreg)

##___ Examples ___:

nnreg(ozone$x,ozone$y,1,2) -> fit # fitting a surface to ozone  
# measurements, from 1 to 2 hidden units 
summary(fit) # summary of fit 

## Keywords: 'neural'.



###--- >>> `make.lags' <<<----- Lags vectors and covariates for fitting an autoregressive model.

	## alias	 help(make.lags)

##___ Examples ___:

make.lags(rossler.state[,1],c(1,2,3)) -> data   
# create   
# 3-d time delay vector model of the x variable of rossler system. 
nnreg(data$x,data$y,5,5) -> fit # fit time series model using nnreg. 
# fitting a state space model to the rossler state vector 
# only one lag is needed in this case.  
make.lags(rossler.state, lags=c(1))-> data 
nnreg( data$x, data$y[,1], 5,5)-> fit1 
nnreg( data$x, data$y[,2], 5,5)-> fit2 
nnreg( data$x, data$y[,3], 5,5)-> fit3 

## Keywords: 'misc'.



###--- >>> `nnregCI' <<<----- Finds a confidence set of parameters for a neural net fit.

	## alias	 help(nnregCI)

##___ Examples ___:

nnreg(ozone$x,ozone$y,1,2) -> fit # fitting a surface to ozone  
# measurements, from 1 to 2 hidden units 
nnregCI(fit) -> fit.ci # finds 500 fits in the .95 confidence set based 
# on the best model from the above fit 

## Keywords: 'neural'.



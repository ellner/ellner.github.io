###--- >>> `print.lle' <<<----- Prints summary statistics of local Lyapunov exponents

	## alias	 help(print.lle)

##___ Examples ___:


nlar( rossler[1:200], lags=1:3, method="nnreg", k1=5)-> out
lle(out) -> rossler.lle  # LLEs of Rossler data 

print(rossler.lle)  # plot LLEs 
# or just
rossler.lle


## Keywords: 'ts'.



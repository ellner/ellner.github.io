###--- >>> `lle.nlar' <<<----- Calculates local Lyapunov exponents from an nonlinear autoregressive model fit.

	## alias	 help(lle.nlar)

##___ Examples ___:


nlar( rossler[1:200], lags=1:3, method="nnreg", k1=5)-> out 

lle( out) -> rossler.lle 

summary( rossler.lle)


## Keywords: 'ts'.



###--- >>> `summary.netfit' <<<----- Summary of parameters of netfit object

	## alias	 help(summary.netfit)

##___ Examples ___:

nnreg(ozone$x,ozone$y,1,3) -> fit           # nnreg fit 
summary(fit$model[[1]],fit$x)               # summary of model 1  
# parameters 

## Keywords: 'neural'.



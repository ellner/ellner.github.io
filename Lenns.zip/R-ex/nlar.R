###--- >>> `nlar' <<<----- Nonlinear autoregressive model

	## alias	 help(nlar)

##___ Examples ___:

# Fit the rossler series. A toy dynamical system that is chaotic 
# Use a neural network with 4 hidden units based on lags 1, 2 and 3 of 
# the series.  
nlar( rossler,lags=c(1,2,3), method="nnreg",k1=4)-> out 
summary(out) 
plot( out) 
lle( out) # calculate local and global Lyapunov exponents 

## Keywords: 'ts'.



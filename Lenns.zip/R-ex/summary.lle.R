###--- >>> `summary.lle' <<<----- Prints summary statistics of local Lyapunov exponents

	## alias	 help(summary.lle)

##___ Examples ___:


nlar( rossler,lags=c(1,2,3), method="nnreg",k1=4)-> fit
lle(fit) -> rossler.lle  # LLEs of Rossler data 

print(rossler.lle)  # plot LLEs 
# or just
rossler.lle


## Keywords: 'ts'.



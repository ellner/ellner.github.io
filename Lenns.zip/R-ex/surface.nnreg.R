###--- >>> `surface.nnreg' <<<----- Plots the predicted surface from an nnreg fit

	## alias	 help(surface.nnreg)

##___ Examples ___:


# fitting a surface to ozone surface(fit) 
 nnreg(ozone$x,ozone$y,1,3) -> fit 
# plots surface and contours of nnreg fit 
surface( fit, type="I")

nnreg(as.matrix(BD[,1:4]),BD$lnya,1,1) -> fit 
gl<- list( KCl="x", MgCl2="y",  KPO4=32, dNTP=800)
surface(fit, grid.list=gl) 


## Keywords: 'hplot'.



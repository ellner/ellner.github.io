###--- >>> `summary.nlar' <<<----- A summary or a nonlinear autoregressive model.

	## alias	 help(summary.nlar)

##___ Examples ___:


nlar( rossler,lags=c(1,2,3), method="nnreg",k1=4)-> out

summary(out, digits=3) # summary but limit output to 3 significant  digits


## Keywords: 'ts'.



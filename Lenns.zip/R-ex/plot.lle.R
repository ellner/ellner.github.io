###--- >>> `plot.lle' <<<----- Plots local Lyapunov exponents

	## alias	 help(plot.lle)

##___ Examples ___:

nlar( rossler[1:200], lags=1:3, method="nnreg", k1=5)-> out
lle(out) -> rossler.lle  # LLEs of Rossler data 
plot(rossler.lle)  # plot LLEs 

## Keywords: 'hplot'.



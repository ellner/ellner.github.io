###--- >>> `plot.nlar' <<<----- Diagnostic plots for a nonlinear autoregrssive model.

	## alias	 help(plot.nlar)

##___ Examples ___:

nlar( rossler,lags=c(1,2,3), method="nnreg",k1=4)-> out
plot( out)

## Keywords: 'hplot'.



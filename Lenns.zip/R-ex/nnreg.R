###--- >>> `nnreg' <<<----- Fits a surface based on a neural network

	## alias	 help(nnreg)

##___ Examples ___:

# quick example to test things.  
xg<- make.surface.grid( list( 1:10,1:10)) # 10X10 grid of points 
y<-  5* exp(-((xg[,1]-5))**2) + exp(.5*(xg[,2]-5))    
#Gaussian ridge in first variable and slope in second 
nnreg( xg, y, 2,4, fast=T)-> look 
summary( look) 
plot(look) # diagnostic plots  
surface( look) #  fitted surface 
# fit using greedy algorithm 
nnreg( xg, y, 2,4, fast=T, greedy=T)-> look2 
summary( look2) 
# NOTE: greedy does better than in fast mode because the larger full 
# models  are not fit as well with full optimzation  
#
# Try leaving out the fast option for the first case.  
# refit using starting values based on the third model from fast fit  
# (four hidden units) 
nnreg( xg, y, start= look$model[[3]])-> look4 
summary( look4)
#
#
# fitting a spatial surface to  
# midwest daily ozone measurements, day 16  (1987 June 18) 
# with 4 through 8 hidden units 
#
data( ozone2)
nnreg(ozone2$lon.lat,ozone2$y[16,],4,8) -> fit 
#
#
predict.surface(fit, model=3)-> out.p # predict with 3rd model
plot.surface( out.p, type="C") # image plot with legend and contours
US( add=T,col=2) 
points( fit$x) 
# 
# 
nnreg(as.matrix(BD[,1:4]),BD[,5],2,4) -> fit # fitting DNA strand 
# displacement amplification surface to various buffer compositions 
plot(fit) # plots fit and residuals 

## Keywords: 'neural'.



###--- >>> `get.LENNS.EXEC' <<<----- Determines directory path to the LENNS standalone program directory.

	## alias	 help(get.LENNS.EXEC)

##___ Examples ___:

get.LENNS.EXEC()

## Keywords: 'misc'.



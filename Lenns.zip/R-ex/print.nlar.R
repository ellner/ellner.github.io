###--- >>> `print.nlar' <<<----- Prints summary of a nonlinear autoregressive model.

	## alias	 help(print.nlar)

##___ Examples ___:

nlar( rossler,lags=c(1,2,3), method="nnreg",k1=4)-> out
 out


## Keywords: 'ts'.



###--- >>> `lle' <<<----- Calculates local Lyapunov exponents for plotting.

	## alias	 help(lle)

##___ Examples ___:

make.lags(rossler[1:200],c(1,2,3)) -> data  # create 
# 3-d time delay vector model of the x variable of rossler system. 
nnreg(data$x,data$y,5,5) -> fit # fit time series model using nnreg. 
jac<- predict(fit, derivative=1)  
lle( jac, lags= c(1,2,3))-> rossler.lle  # LLEs of Rossler data 
summary(rossler.lle) 
plot(rossler.lle)  # plot LLEs 
# here is an easier way 
nlar( rossler[1:200], lags=1:3, method="nnreg", k1=5)-> out 
lle( out) -> rossler.lle 

## Keywords: 'ts'.



###--- >>> `predict.netfit' <<<----- Evaluation of a neural net fit based on a model component

	## alias	 help(predict.netfit)

##___ Examples ___:

nnreg(ozone$x,ozone$y,1,2) -> fit           # nnreg fit 
cbind( seq(87,89,,3),seq(40,42,,3)) -> x   # new x 
predict(fit$model[[1]],x) -> out            # evaluate model 1 at x 

## Keywords: 'neural'.



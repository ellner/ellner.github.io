function [b,bint,r,rint,info] = fitdat(x,y,order);
%  function [b,bint,r,rint,info] = fitdat(x,y,order);
%  input   x -- independent varible
%          y -- dependent variable
%          order --  the order of the regression fit
%
% this function simply automates fitting higher order regression
% with matlab's reg function

xn = [];
for i = 1:order, xn = [xn,x.^i];, end;
xn = [ones(max(size(x)), 1), xn];

[b,bint,r,rint,info] = myreg2(y, xn, .95);







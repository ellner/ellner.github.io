function [lambda,a,surv,fecund,cuts] = matlam(dat,numclass);

% this function sets up a matrix and returns
% the matrix and dominant eigenvalue.
% the classes are choosen so the equal numbers will
% be in each class

numcol = size(dat,2);

p = (1:numclass-1)/numclass*100;
cuts = prctile(dat(:,1), p);

lbnd = min(min(dat)) - 10;
ubnd = max(max(dat)) + 10;

cuts = [lbnd; cuts'; ubnd];


%  this is simple enough that it should be vectorized


for i = 1:numclass,
for j = 1:numclass,

temp = (cuts(j)<dat(:,1)) .* (dat(:,1)<=cuts(j+1));
temp2 = (dat(:,2)>cuts(i)).*(dat(:,2)<=cuts(i+1)).*(dat(:,2)~=0);
surv(i,j) = sum(temp.*temp2) ./ sum(temp);

ftemp = dat(dat(:,1)>cuts(j),:);
fdat = ftemp(ftemp(:,1)<=cuts(j+1),:);
fnum = fdat(:,1)~=0;
t1 = fdat(:,4:numcol)>cuts(i);
t2 = fdat(:,4:numcol)<=cuts(i+1);
t3 = fdat(:,4:numcol)~=0;
temp3 = t1.*t2.*t3;

fecund(i,j) = sum(sum(temp3)) ./ sum(fnum);

end;
end;

a = surv + fecund;

lambda = max(eig(a));


% function [survfit, mufit, sigfit] = grow(dat,pics,fits)
%
% grow.m returns the spline and/or regression fits of the
% growth part of the kernel.
% 
% input   dat  -- the matrix of population data
%         pics -- 1 for pictures, any other number for no pictures
%         fits -- a vector of 3 numbers.  first entry is how to fit
%                 the survival probibility.  Second entry is how to
%                 fit the mean growth.  Third entry is how to
%                 fit the variance in growth.  Enter a 1 for
%                 spline and 2 for regression
% return  survfit, mufit, sigfit  -- these hold the piecewise polynomial from
%                                 a spline fit or the regression coefficients
%                                 from a regression fit.


function [survfit, mufit, sigfit] = grow(dat, pics, fits)
global xval yval knots
global surv_order grow_order vargrow_order

myopt = zeros(14,1);
myopt(14) = 2000;

xval = dat(:,1);
yval = dat(:,2)~=0;

if fits(1) == 1,

p = [50];
knots = [min(xval); prctile(dat(:,1),p); max(xval)];
init = [ 0.5 0.5 0.5];
sval = fmins('maxlik', init, myopt);
survfit = csapi(knots, sval);

else
	survfit = fitdat(xval,yval,surv_order);
end;

if pics == 1,
	figure;
	subplot(2,2,1);
	t = ' ';
	makepic(xval,yval,survfit,fits(1),t);
	ylabel('survival probability');
	xlabel('size at time t');
	text(5.4,0.9,'A')

end;

xval = dat(dat(:,2)~=0,1);
yval = dat(dat(:,2)~=0,2);

if fits(2) == 1;

p = [33 66];
knots = [min(xval);prctile(xval, p)';max(xval)];
init = knots;
muval = fmins('fitspl', init, myopt);
mufit = csapi(knots, muval);

else
	[mufit,muint,r] = fitdat(xval,yval,grow_order);
end;

if pics == 1,
	subplot(2,2,2);
	t = ' ';
	makepic(xval,yval,mufit,fits(2),t);
	xlabel('size at time t');
	ylabel('size at time t+1');
	text(5.4,5.5,'B')
end;

if fits(3) == 1,

	pred = fnval(mufit, xval)';
	resid = pred - yval;
	size(resid)
	if pics == 1,
		subplot(2,2,3);

		hist(resid,15);
%		plot(xval,resid,'ko')
		xlabel('residual');
		ylabel('residual frequency');
		text(2.5,90,'C')

	end

	yval = resid.^2;
	init = [0.3 0.3 0.3 0.3];
	sigval = fmins('varspl', init, []);
	sigfit = csapi(knots, sigval);

else
	yval = r.^2;
	if pics == 1,
		subplot(2,2,3);

%		plot(xval,r, 'ko')
		hist(r,15);
		h = get(gca, 'Children');
		set(h,'FaceColor', 'w');
		xlabel('residual')
		ylabel('residual frequency')
		text(2.5,90,'C')
	end
	[sigfit] = fitdat(xval, yval,vargrow_order);
end;

if pics == 1,
	subplot(2,2,4)
	t = ' ';
	makepic(xval,yval,sigfit,fits(3),t);
end;
	ylabel('variance of growth');
	xlabel('size at time t');
	text(5.4,5.5,'D')


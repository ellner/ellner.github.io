function [kd, xvals] = kernmat(n, mshmin, mshmax)

% this function sets up the matrix from the kernel

[x,wgts] = gualag(mshmin,mshmax,n);
y = x;
xvals = x;

[x,y] = meshgrid(x,y);
k = mkkern(x,y);
%k = truekrn(x,y);
%k = kern(x,y);

temp = eye(n);
for i = 1:n
temp(i,i) = wgts(i);
end

d = temp;

kd = k*d;



function val = maxlik(temp)

%  function val = maxlik(temp)
%
%  function for fitting the maximum likelihood for
%  survival probability.  

global xval yval knots;

pp = csapi(knots,temp);

p = fnval(pp,xval);
plus = max(p-1,0);
neg = max(-p,0);
p = min(max(p,0.0000001),0.99999999);

lik = sum(log(yval.*p + (1-yval).*(1-p)));

val = -1 .* lik;

val = val + 25.*sum(plus.^2) + 25.*sum(neg.^2);

This Zip archive contains Matlab and Splus/R code for
the Integral projection model as described in Easterling,
Ellner, and Dixon (2000), with documentation and
some sample data. This version was produced 9/21/99, and if that
was a long time ago, then you should probably see if there is
a better version available by contacting one of the authors. 
For now you can reach us at:
	Steve Ellner: ellner@stat.ncsu.edu
	Mike Easterling: easterling.michael@epa.gov
	Philip Dixon: pdixon@iastate.edu

The Splus/R code consists of two files (kernelfit.R and kernelrun.R) with embedded 
comments. It steps through a simplified version of the
Monkshood case study in Easterling, Ellner and Dixon (2000),
ending with an implementation of the "big matrix" trick in which
a fictitious matrix projection model is constructed such that
conventional analysis of this projection model gives approximate
numerical solutions to the integral model. It has been tested
in Splus2000 for Windows, and R version 0.650 for Windows. 
In order to run the R version you need the splines library for R. 
You will also need to modify the code to suit your problem 
(e.g., to read in your data and use the selected models to compute the kernel). 
Splus is a commercial package but R is FREE and versions are available for PC 
and UNIX from CRAN (www.cran.r-project.org).   

The Matlab code has a brief manual (manual.doc and manual.pdf). 
The code consists of all the *.m files. It implements an efficient numerical
solution of the integral model using Gauss-Legendre quadrature.
This is not compiled code: you need Matlab in order to run it. 

Both codes operate on data sets in a specific format, that is
described in the Matlab code manual. Testdata.txt is a sample simulated 
data file in the proper format, and monkdata is a subset of the Monkshood 
data analyzed by Easterling et al (2000).



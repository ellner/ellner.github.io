% function [grow_rates,kmat,mshpts] = lambda(dat)
%
% This function calculates the growth rate for the population
% data set.  It calls grow.m and fecund.m to fit the components
% of the kernel.
%
%  input:  dat   -- matrix with the data
%
%  return: grow_rates -- 3 values of the growth rate
%          1.  from the integral model
%          2.  from the data (# @ time t+1 / # @ time t)
%          3.  from a matrix with a user definded number of classes
%
%  grow_rates = [ilam dlam mlam]

function [grow_rates, kmat, mshpts] = lambda(dat)
global survpp growpp vgrowpp cut mkpp vkpp ksizpp vsizpp
global mshmin mshmax
global lowval hival
global grofit fecfit 
global surv_order grow_order vargrow_order 
global num_off_order offsize_order offvar_order

% USER SETS PARAMETERS OF THE FITS

% Number of stage classes in the fitted matrix model
numclass = 5;

% Parameters of the integral model fit
% The three parts for growth are: survival vs. size, new size vs. 
% old size, and variance of new size vs. old size. 
% The three parts for fecundity are: #offspring vs. size, mean
% offpring size vs. parent size, variance of offspring size.
 
% How each part of the integral model is fit
% 1 for spline
% 2 for regression
% NOTE: the spline option uses a cubic smoothing spline, and requires
% the spline toolbox in Matlab. 
surv_fit_method = 2;
grow_fit_method = 2;
vargrow_fit_method = 2;
num_off_fit_method = 2;
offsize_fit_method = 2;
offvar_fit_method = 2;

% The order of each regression if regression is the selected fitting method.
surv_order = 1;
grow_order = 2;
vargrow_order = 2;
num_off_order = 1;
offsize_order = 1;
offvar_order = 1;

% plot data fits?   1=yes  2=no
dopics = 1;

% # of mesh points at which kernel value is calculated
% # kernmat (matrix of kernel values) is mshsize x mshsize 

mshsize = 100;

%*************USER SHOULD NOT EDIT BEYOND THIS LINE*******************

grofit = [surv_fit_method grow_fit_method vargrow_fit_method];
fecfit = [num_off_fit_method offsize_fit_method offvar_fit_method];

%  Fit the parts of the kernel
[survpp, growpp, vgrowpp] = grow(dat,dopics,grofit);
[cut, mkpp, ksizpp, vsizpp] = fecund(dat,dopics,fecfit);
vals = [min(dat(:,1)), max(dat(:,1))];
lowval = vals(1);
hival = vals(2);

if grofit(3) == 1,
sigs = sqrt(max(0.000001,fnval(vgrowpp, vals)));
else,
sigs = sqrt(max(0.000001,(vgrowpp(1) + vgrowpp(2).*vals)));

mshmin = vals(1) - 3.*sigs(1);
mshmax = vals(2) + 3.*sigs(2);

% - - - - Solve the integral equation for lambda - - - - - -
[kmat, mshpts] = kernmat(mshsize, mshmin, mshmax);
[ilam, lammeth] = intlam(kmat);
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


% - - - - Calculate lambda from the data #t+1 / # t - - - - -
dlam = datlam(dat);
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


% - - - - Fit a matrix and calculate lambda - - - - - - - - -
mlam = matlam(dat,numclass);
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

grow_rates = [ilam, dlam, mlam];

end;



# This code picks up at the point where all components of the kernel
# have been fitted, and computes the kernel, elasticity, and 
# sensitivity surfaces. 
#
# The code is set up to run in Splus for Windows, because the surface plotting
# routines are better than those in R. The plots are done using
# function plotsurf() below; R users should replace calls to plotsurf
# with calls to plotsurfR, which actually produces a contour plot. 
# Users of Splus for UNIX may also need to make minor changes in the
# plotting functions. 
# 
# The user needs to modify parts (I) and (II), which specify the
# data set and the functional forms of the model. You can then
# run parts (III) and (IV) to get a 100 x 100 "big matrix" and
# graphical output of the kernel, elasticity, and sensitivity.
# The rest is up to you. Note that a "big matrix" in this program
# is a composite object with components matrix, kernel, and meshpoints.
#  
# Part (I) 
#   Data are read in only to compute the range of
#   observed sizes, and this can be replaced by assigning numerical
#   values to minsize and maxsize. Users needs to modify the code
#   to read in their own data.  
# Part (II)
#   Functions are created to compute values of the fitted models
#   for components of the kernel. Users need to substitute their
#   own fitted models. The ones here are taken from the Figure
#   legends in Easterling et al. (2000).   
# Part (III) 
#   Functions are created to compute the kernel, the "big matrix",
#   and the sensitivity and elasticity from the matrix. The user
#   does not need to modify anything in this section.
#   The function emat() computes block elasticities, corresponding
#   to figures 6 and 7 in Easterling et al. (2000), which should
#   be consulted for an explanation of what emat() is doing. 
# Part (IV)
#   The functions created in parts (II) and (III) are used to compute
#   and plot the kernel, elasticity, and sensitivity surfaces for
#   a 100 x 100 "big matrix". 
#
# In R you need the splines library; in Splus comment out the next line.
# library(splines); 


# Part (I) ##############################################################
# Read in the data to find range of observed sizes 
monk<-read.table("d:\\students\\easter\\monkdata.txt"); 
monk<-as.matrix(monk); size<-monk[,1]; 
minsize<-range(size)[1]; maxsize<-range(size)[2];

# Part (II) ##############################################################
# Compute the kernel component functions from the fitted models
sx<-function(x) {
	u<-exp(1.34+0.92*x); return(u/(1+u));
}

gxy<-function(x,y) {
	sigmax2<-0.127+0.23*x;
	sigmax<-sqrt(sigmax2);
	mux<-0.37+0.73*x;
	fac1<-sqrt(2*pi)*sigmax;
	fac2<-((y-mux)^2)/(2*sigmax2);
	return(exp(-fac2)/fac1);
}

pxy<-function(x,y) { return(sx(x)*gxy(x,y)) }

fxy<-function(x,y) {
	nkids<-0.034+0.038*x;
	kidsize.mean<- -0.3+0.57*x;
	kidsize.var<- -0.0046+0.192*x; 
	fac1<-sqrt(2*pi)*sqrt(kidsize.var);
	fac2<-((y-kidsize.mean)^2)/(2*kidsize.var);
	f<-(7/18)*nkids*exp(-fac2)/fac1;
	f2<-(11/18)*nkids/(0.1);
	if(y<=0.25) {if(y>=0.15) f<-f+f2};
	if(x<1) f<-0; 
	return(f);
}


# Part (III) ################################################################
# THE KERNEL K(y,x) 
# note the chopoff
minsize<-range(size)[1]; maxsize<-range(size)[2]; 
Kyx<-function(y,x) {
	xeval<-max(x,minsize); xeval<-min(xeval,maxsize);
	yeval<-max(y,minsize); yeval<-min(yeval,maxsize);
	return(pxy(xeval,yeval)+fxy(xeval,yeval))
	};

############## The 'big matrix' M of size n x n
bigmatrix<-function(n) {
# upper and lower integration limits
	L<-0; U<-1.1*maxsize;
	
# boundary points b and mesh points y
	b<-L+c(0:n)*(U-L)/n;
	y<-0.5*(b[1:n]+b[2:(n+1)]);

# loop to construct the matrix
	M<-matrix(0,n,n);
	for (i in 1:n){
		cat(i); 
		for(j in 1:n){
			M[i,j]<-Kyx(y[i],y[j])
		}
	}
	K<-M; 
	M<-(U-L)*M/n;
	return(list(matrix=M,kernel=K,meshpts=y)); 
}



sens<-function(A) {
	w<-Re(eigen(A)$vectors[,1]); 
	v<-Re(eigen(t(A))$vectors[,1]);
	vw<-sum(v*w);
	s<-0*A;
	n<-dim(A)[1];
	for (i in 1:n){
		for (j in 1:n) {
			s[i,j]<-v[i]*w[j]
		}
	}
	return(s/vw); 
}	

elas<-function(s,A) {
	lam<-Re(eigen(A)$values[1]);
	return((s*A)/lam);
}

emat<-function(M,breaks) {
	x<-M$meshpts; nx<-length(x); 
	sen<-sens(M$matrix); 
	Ematrix<-elas(sen,M$matrix); etot<-sum(Ematrix);
	cuts<-0*breaks; nbreaks<-length(breaks);
	for (i in 1:nbreaks) {
		e<-x<breaks[i]; cuts[i]<-sum(e);
	}
	cuts<-c(0,cuts,nx); nclass<-length(cuts)-1;
	evals<-matrix(0,nclass,nclass);
	for (i in 1:nclass){
		for (j in 1:nclass){
			imin<-cuts[i]+1; imax<-cuts[i+1];
			jmin<-cuts[j]+1; jmax<-cuts[j+1];
			evals[i,j]<-sum(Ematrix[imin:imax,jmin:jmax]);
		}
	}
	return(evals); 
}

################ plot matrix
plotsurf<-function(M,meshpts) {
	persp.setup(lty=c(1,1,1), col=c(1,1,1), lwd=c(2,1,1));
	eyevec<-c(80,-30,8*range(M)[2]);
	q<-sum(meshpts<=maxsize); 
	persp(meshpts[1:q],meshpts[1:q],M[1:q,1:q], eye=eyevec, 
		xlab="size at time t+1", ylab="size at time t");
	return(0);
}	

plotsurfR<-function(M,meshpts) {
	q<-sum(meshpts<=maxsize); 
	contour(meshpts[1:q],meshpts[1:q],M[1:q,1:q],  
		xlab="size at time t+1", ylab="size at time t");
	return(0);
}	


# Part (IV) ##############################################################

M<-bigmatrix(100); 

win.graph();
par(mfrow=c(1,1));
sen<-sens(M$matrix); dx<-M$meshpts[2]-M$meshpts[1];
plotsurf(sen/(dx^2),M$meshpts); title("Sensitivity");

par(mfrow=c(1,1));
e<-elas(sen,M$matrix); 
plotsurf(e,M$meshpts); title("Elasticity");

breaks<-c(0.2,0.6,1.154,1.702);
fig6a<-emat(M,breaks);

breaks<-c(0.2,2,4); 
fig7a<-emat(M,breaks);

lam<-Re(eigen(M$matrix)$values[1]); lam;
w<-Re(eigen(M$matrix)$vectors[,1]); w<-w/mean(w); 
v<-Re(eigen(t(M$matrix))$vectors[,1]); v<-v/v[1]; v<-v/(2*range(v)[2]); 
persp(M$meshpts,M$meshpts,M$kernel, eye=c(30,-30,15), zlim=c(0,1.5),
xlab="size at time t+1", ylab="size at time t"); title("Kernel");

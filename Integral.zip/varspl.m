function sumsq = varspl(temp)
global xval yval knots;

%pp = csapi(knots, temp);
pp = spline(knots, temp);
zval = fnval(pp, xval);
neg = max(-zval,0);
sumsq = sum( (zval - yval').^2 ) + 10.*sum(neg.^2);
end;




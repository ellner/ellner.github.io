function myans = wvprod(x)

global wvpp

myans=ppval(wvpp,x);

function [lambda, lammeth, eigfcn] = intlam(kmat)


% function to get eigenvalues/vectors for a matrix
% either by using eig2.m or by iterating the matrix model

noans = 0;
lammeth = 1;

tkmat = kmat';

eval('[rteig,rlamb] = eig2(kmat);','noans = 10;');
eval('[lfeig,llamb] = eig2(tkmat);','noans = 10;');

if noans == 0,

	eigfcn = [rteig, lfeig];
	lambda = rlamb;

else,

	lammeth = 2;
	matpow = (kmat^75)*ones(125,1);
	lambda = sum(kmat*matpow) / sum(matpow);

end;


%end;



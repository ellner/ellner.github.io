function lambda = datlam(dat)

% Calculate lambda from the data
% this is simply (# of individuals at t+1)/(# of individuals at t)

colnum = size(dat,2);
newsiz = sum(dat(:,2)~=0) + sum(sum(dat(:,4:colnum)~=0));
oldsiz =sum(dat(:,1)~=0);
lambda = newsiz./oldsiz;



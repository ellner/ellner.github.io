function makepic(x,y,pp,fittype,t)
%
%  makes plot of the data overlayed with the fit

xval = min(x):0.01:max(x);
if fittype == 1,
	yval = fnval(pp,xval);
else
	yval = zeros(1,max(size(xval)));	
	for i = 1:max(size(pp)), 
	yval = yval + pp(i).*xval.^(i-1);
	end;
end;

plot(x,y,'ko',xval,yval,'k-');
title(t);


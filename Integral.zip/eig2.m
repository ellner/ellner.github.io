% function [efcn, lambda] = eig2(A)
%
% this routine returns the dominant eigenvalue "lambda"
% and it's associated eigenvector "efcn" given the 
% matrix A.   It uses matlab's standard eig function to
% calculate the eigenvalue and eigenvector.
 
function [efcn,lambda] = eig2(A)
[vec,val] = eig(A);
eigval = diag(val);
[temp,indx] = max(abs(eigval));
lambda = val(indx,indx);
efcn = vec(:,indx);


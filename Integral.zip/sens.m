function [sens_kernel, elas_kernel] = sens(kernel,xvals)
%
%  the function returns the sensitivity and elasticity of
%  the kernel.  It will plot the eigenvectors, the sensitivity
%  and the elasticity.   Change from mesh to contour if you want
%  a contour plot instead of a surface plot.

global wvpp

[lambda, lammeth, eigfcns] = intlam(kernel);

figure
subplot(2,1,1)
plot(xvals, eigfcns(:,1)./sum(eigfcns(:,1)))
title('Stable Size Distribution')
xlabel('Size')
subplot(2,1,2)
plot(xvals, eigfcns(:,2)./eigfcns(1,2))
title('Reproductive Value')
xlabel('Size')

wvpp=spline(xvals,eigfcns(:,2).*eigfcns(:,1));
q=quad('wvprod',min(xvals),max(xvals));

sens_kernel = eigfcns(:,2)*eigfcns(:,1)'/q;
sens_kernel=transpose(sens_kernel);

[xx, yy] = meshgrid(xvals,xvals);

figure
mesh(xx,yy,sens_kernel)

elas_kernel = kernel.* sens_kernel/ lambda;
figure
mesh(xx,yy,elas_kernel)


# This code runs through a sample data analysis for fitting survival,
# mean growth, variance of growth, and number of offspring
# and using the results to compute the fitted kernel function K(y,x).
# It is a 'template' meaning that you will have to modify it for your
# own purposes, and save the model selected for your data rather than
# the one selected for min. Before modifying this code, please be
# sure to copy it under a different name (such as mykernel.ssc)
# and MODIFY THE COPY. 
#
# The code should be stepped through, one line at a time; "source"ing the
# entire file will not give useful results. The data file is only a subset
# of that used in Easterling et al. (2000), and the model fitted here
# ignores the bimodal size distribution of offspring.  
#
# There are 3 "parts" to the code: (I) reading in the data , (II) fitting the
# model components, and (III) combining the components to compute the kernel
# and construct the "big matrix". In this sample analysis we construct
# matrices of size 50 x 50 and 100 x 100 and compare the results; since they
# are nearly identical the 50 x 50 matrix is big enough. 



############################# PART (I) ####################################
# Read in the data MODIFY THE PATH FOR YOUR FILE SYSTEM
monk<-read.table("d:\\students\\easter\\monkdata.txt"); 
monk<-as.matrix(monk); 

# Sort the data for convenience in plotting
size<-monk[,1]; os<-order(size); 
monk<-monk[os,]; size<-monk[,1]; 
lived<-monk[,2]>0;

# In R you need the splines library; in Splus comment out the next line.
# library(splines); 


############################# PART (II) ####################################
############### Survivorship function 
# Plot the data 
plot(size,lived);

#Fit a linear survivorship function
m1<-glm(lived~size,family=binomial);

# Fit a quadratic survivorship function
size2<-size^2
m2<-glm(lived~size+size2,family=binomial);

# Fit a B-spline survivorship function
m3<-glm(lived~bs(size,4),family=binomial);

# Compare linear and spline fits
plot(size,m1$fitted.values,ylim=c(0.8,1));
points(size,m3$fitted.values,type="l");
title("Linear(dots) and Bspline(line) logistic regression models"); 

#Tests to see if linear is rejected: NO. (test="Cp" gives same conclusion).
anova(m1,m2,test="Chi"); 
anova(m1,m3, test="Chi"); 

# Save the linear model
s.intercept<-m1$coefficients[1]; 
s.slope<-m1$coefficients[2]; 

################## Mean growth function
# Extract & plot sizes of individuals that survived from t=0 to t=1
s0<-monk[lived,1]; s1<-monk[lived,2];
plot(s0,s1,xlab="Size at time t",ylab="Size at time t+1");

# Fit linear, quadratic, and B-spline growth functions
m1<-glm(s1~s0); 
s02<-s0^2; m2<-glm(s1~s0+s02); 
m3<-glm(s1~bs(s0,3)); 

# Overlay all 3 fits on the data
points(s0,m1$fitted.values,type="l");
points(s0,m2$fitted.values,type="l");
points(s0,m3$fitted.values,type="l");

# Anova tests of linear model: NOT REJECTED 
anova(m1,m3,test="Chi");
anova(m1,m2,test="Chi");

# Save the linear model
gmean.intercept<-m1$coefficients[1];
gmean.slope<-m1$coefficients[2]

###################### Variance of growth
# Fit the linear model for new size vs. old size, and squared residuals
sizemod<-lm(s1~s0); r1<-(sizemod$residuals)^2;

# chop off a few 'outliers' with excessive leverage on the fits
notbig<-s0<4; px<-s0[notbig]; py<-r1[notbig]; 

# Fit linear,cubic, B-spline models for squared residuals
m1<-glm(py~px); 
px2<-px^2; px3<-px^3; m2<-glm(py~px+px2+px3);
m3<-glm(py~bs(px,4));

#Anova test of linear model 
anova(m1,m2,test="Chi"); 
anova(m1,m3,test="Chi");

# Plot to compare models, here the linear and quadratic
plot(px,py,xlab="size at time t", ylab="squared growth residual");
points(px,m1$fitted.values,type="l");
points(px,m2$fitted.values,type="l",lty=3);

# Save the linear model
gvar.intercept<-m1$coefficients[1];
gvar.slope<-m1$coefficients[2];

########## Mean number of offspring 
kids<-monk[,3]; plot(size,kids);
yy<-as.variable(kids[size>=1]); xx<-as.variable(size[size>=1]); 
m1<-glm(yy~xx,family=poisson);
# -- note that glm family=poisson has the log link function: see below in f(x,y)
points(size[size>=1],m1$fitted.values,type="l");
kids.intercept<-m1$coefficients[1];
kids.slope<-m1$coefficients[2]; 

######### Offspring size distribution
# NOTE: instead of the real 2-part distribution for Monkshood, here we
# assume that offspring size is Gaussian & independent of parent size.

# Extract all offspring sizes
kidsizes<-as.vector(monk[,-c(1:3)]); 
kidsizes<-kidsizes[kidsizes>0];

# Compute mean and variance
kidsize.mean<-mean(kidsizes);
kidsize.var<-var(kidsizes); 



############################# PART (III) ####################################

# survival function s(x)
sx<-function(x) {
	xbeta<-s.intercept+x*s.slope;
	return(exp(xbeta)/(1+exp(xbeta)));
}

# growth function g(x,y)
gxy<-function(x,y) {
	sigmax2<-gvar.intercept+x*gvar.slope;
	sigmax<-sqrt(sigmax2);
	mux<-gmean.intercept+x*gmean.slope;
	fac1<-sqrt(2*pi)*sigmax;
	fac2<-((y-mux)^2)/(2*sigmax2);
	return(exp(-fac2)/fac1);
}

# combine s and g into p(x,y)
pxy<-function(x,y) { return(sx(x)*gxy(x,y)) }

# fecundity function f(x,y) including number and size distribution of kids
fxy<-function(x,y) {
	nkids<-exp(kids.intercept+kids.slope*x);
	# exp() is due to log link function in glm with family=poisson
	fac1<-sqrt(2*pi)*sqrt(kidsize.var);
	fac2<-((y-kidsize.mean)^2)/(2*kidsize.var);
	return(nkids*exp(-fac2)/fac1);
	
}

########## THE KERNEL K(y,x) 
# note the chopoff and smallest and largest observed sizes
minsize<-range(size)[1]; maxsize<-range(size)[2];
Kyx<-function(y,x) {
	xeval<-max(x,minsize); xeval<-min(xeval,maxsize);
	yeval<-max(y,minsize); yeval<-min(yeval,maxsize);
	return(pxy(xeval,yeval)+fxy(xeval,yeval))
	};


############## The 'big matrix' M of size n x n
bigmatrix<-function(n) {
# upper and lower integration limits
	L<-0; U<-1.1*maxsize;
	
# boundary points b and mesh points y
	b<-L+c(0:n)*(U-L)/n;
	y<-0.5*(b[1:n]+b[2:(n+1)]);

# loop to construct the matrix
	M<-matrix(0,n,n);
	for (i in 1:n){
		cat(i); 
		for(j in 1:n){
			M[i,j]<-Kyx(y[i],y[j])
		}
	}
	M<-(U-L)*M/n;
	return(list(matrix=M,meshpts=y)); 
}

# compare results for n=50 and n=100, lambda and stable size distribution
# REMEMBER, this is not the real Monkshood matrix because of the simplified
# size distribution for offspring 
M50<-bigmatrix(50); 
lambda50<-eigen(M50$matrix)$values[1]; lambda50;
ssd50<-Re(eigen(M50$matrix)$vectors[,1]); ssd50<-ssd50/mean(ssd50); 
rrv50<-Re(eigen(t(M50$matrix))$vectors[,1]); rrv50<-rrv50/rrv50[50];

M100<-bigmatrix(100); 
lambda100<-eigen(M100$matrix)$values[1]; lambda100;
ssd100<-Re(eigen(M100$matrix)$vectors[,1]); ssd100<-ssd100/mean(ssd100); 
rrv100<-Re(eigen(t(M100$matrix))$vectors[,1]); rrv100<-rrv100/rrv100[100];

win.graph(); par(mfrow=c(2,1));
plot(M50$meshpts,ssd50,type="l",lty=1,xlab="size",ylab="frequency");
points(M100$meshpts,ssd100,type="l",lty=2);
title("Stable distributions for n=50 and n=100");  

plot(M50$meshpts,rrv50,type="l",lty=1,xlab="size",ylab="Reproductive value");
points(M100$meshpts,rrv100,type="l",lty=2);
title("Relative reproductive value for n=50 and n=100");
 
 












% function [cutoff, nkpp, kidpp, varkpp] = fecund(dat,pics,fits)
%
% fecund.m returns the spline and/or regression fits of the
% fecundity part of the kernel.
% 
% input   dat  -- the matrix of population data
%         pics -- 1 for pictures, any other number for no pictures
%         fits -- a vector of 3 numbers.  first entry is how to fit
%                 the number of offspring.  Second entry is how to
%                 fit the size of offspring.  Third entry is how to
%                 fit the variance in offspring size.  Enter a 1 for
%                 spline and 2 for regression
% return  cutoff  -- minimum size of reproductive individual in the data
%         nkpp, kidpp, varkpp  -- these hold the piecewise polynomial from
%                                 a spline fit or the regression coefficients
%                                 from a regression fit.

function [cutoff, nkpp, kidpp, varkpp] = fecund(dat,pics,fits)
global xval yval knots;
global num_off_order offsize_order offvar_order

kiddat = [];
cutoff = min(dat(dat(:,3)>0,1));

cuttmp = dat(dat(:,1)>=cutoff,:);
xval = cuttmp(:,1);
yval = cuttmp(:,3);

% Use the following two lines if you do not want to pick a cutoff
%xval = dat(:,1);
%yval = dat(:,3);

if fits(1) == 1,
	nkpp = csaps(xval,yval,0.8);
else
	nkpp = fitdat(xval, yval, num_off_order);
end;


if pics == 1,
	figure
	subplot(2,2,1);
	t = ' ';
	makepic(xval,yval,nkpp,fits(1),t);
	xlabel('adult size at time t');
	ylabel('number of offspring');
	text(5.5,3.2,'A');
end;

for j = 4:size(dat,2), 
kiddat = [kiddat; dat(:,1), dat(:,j)];
end;

kiddat = kiddat(kiddat(:,2)~=0,:);

xval = kiddat(:,1);
yval = kiddat(:,2);

if fits(2) == 1,
	knots = [min(xval); prctile(xval,50); max(xval)];
	init = [ -2 -2 -2];
	kidval = fmins('fitspl', init, []);
	kidpp = csapi(knots, kidval);
else,
	[kidpp,junk,resids]  = fitdat(xval,yval,offsize_order);
end;

if pics == 1,
	subplot(2,2,2)
	t =' ';
	makepic(xval,yval,kidpp,fits(2),t);
	xlabel('adult size');
	ylabel('offspring size');
	text(3.7,1.3,'B');
end;

if fits(3) == 1,
	pred = fnval(kidpp,xval)';
	resid = pred - yval;
	if pics == 1,
		subplot(2,2,3);
		t = ' ';
		hist(resid);
		h = get(gca, 'Children');
		set(h,'FaceColor', 'w');
		xlabel('residual');
		ylabel('residual frequency');
		text(0.85,4.6,'C')
	end;

	yval = resid.^2;
	init = [ 1 1 1 ];
	ksigval = fmins('varspl', init , []);
	varkpp = csapi(knots, ksigval);
else,
	yval = resids.^2;
	if pics == 1,
		subplot(2,2,3);
		t = ' ';
		hist(resids);
		h = get(gca, 'Children');
		set(h,'FaceColor', 'w');
		xlabel('residual');
		ylabel('residual frequency');
		text(0.85,4.6,'C')
	end;

	varkpp = fitdat(xval,yval,offvar_order);
end;


if pics == 1,
	subplot(2,2,4)
	t = ' ';
	makepic(xval,yval,varkpp,fits(3),t);
	xlabel('adult size');
	ylabel('offspring size variance');
	text(3.7,0.72,'D');
end;



function kxy = mkkern(x,y)
%  function kxy = mkkern(x,y)
%
%  mkkern creates the matrix from the kernel fits.
%  given x and y, mkkern returns the value of the kernel
%  at (x,y).

global survpp growpp vgrowpp cut mkpp vkpp ksizpp vsizpp;
global lowval hival;
global grofit fecfit;
p1 = [];
f1 = [];
x = min(max(x,lowval),hival);
xsqr = x.^2;

% previous line projects back in to the range where I fit data

f3 = x>=cut;

if fecfit(1) == 1,
	fmean1 = max(fnval(mkpp,x(1,:)),0);
	for i = 1:size(x,2),
		f1 = [f1; fmean1];
	end;
else,
	f1 = zeros(size(x));
	for i = 1:max(size(mkpp)),
	f1 = f1 + mkpp(i).*x.^(i-1);
	end;
%	f1 = mkpp(1) + mkpp(2).*x + mkpp(3).*xsqr;
end;

if fecfit(2) == 1,
	fmean2 = fnval(ksizpp,x(1,:));
	fsig2 = sqrt(max(0.0001,fnval(vsizpp,x(1,:))));
	for i = 1:size(x,2),
		fmean2m = [fmean2m; fmean2];
		fsig2m = [fsig2m; fsig2];
	end
	f2 = normpdf(y,fmean2m,fsig2m);
else,
	fmean2 = zeros(size(x));
	fsig2 = zeros(size(x));
	for i = 1:max(size(ksizpp)),
	fmean2 = fmean2 + ksizpp(i).*x.^(i-1);
	end;	
%fmean2 = ksizpp(1) + ksizpp(2).*x +ksizpp(3).*xsqr;
	for i = 1:max(size(vsizpp)),
	fsig2 = fsig2 + vsizpp(i).*x.^(i-1);
	end;
%	fsig2 = sqrt(max(0.0001,vsizpp(1) + vsizpp(2).*x + vsizpp(3).*xsqr));
	fsig2 = sqrt(max(0.00001,fsig2));	
	f2 = normpdf(y,fmean2, fsig2);
end;

f1 = max(0,f1);
f2 = max(0,f2);
fxy = f1.*f2.*f3;

if grofit(1) == 1,
ptemp = min(1,max(fnval(survpp,x(1,:)),0));
for i =  1:size(x,2),
	p1 = [p1; ptemp];
end;
else,
	p1 = zeros(size(x));
	for i = 1:max(size(survpp)),
	p1 = p1 + survpp(i).*x.^(i-1);
	end;	
%	p1 = survpp(1)+survpp(2).*x+survpp(3).*xsqr;
end;

if grofit(2) == 1,
tpmean1 = fnval(growpp,x(1,:));
tpsig1 = sqrt(max(0.0001,fnval(vgrowpp,x(1,:))));

for i = 1:size(x,2),
	pmean1 = [pmean1; tpmean1];
	psig1 = [psig1; tpsig1];
end;

else,
	pmean1 = zeros(size(x));
	psig1 = zeros(size(x));
	for i = 1:max(size(growpp)),
	pmean1 = pmean1 + growpp(i).*x.^(i-1);
	psig1 = psig1 + vgrowpp(i).*x.^(i-1);
	end;
%	pmean1 = growpp(1)+growpp(2).*x+growpp(3).*xsqr;
%	psig1 = sqrt(max(0.00001,vgrowpp(1)+vgrowpp(2).*x+vgrowpp(3).*xsqr));
	psig1 = sqrt(max(0.000001, psig1));
end;


p2 = normpdf(y, pmean1, psig1);

p1 = max(0,p1);
p2 = max(0,p2);

pxy = p1 .* p2;

kxy = pxy + fxy;






function sumsq = fitspl(temp)
global xval yval knots;
pp = csapi(knots, temp);
zval = fnval(pp, xval);
sumsq = sum( (zval - yval).^2 );


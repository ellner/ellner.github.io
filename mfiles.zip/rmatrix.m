function B=rmatrix(A,S,Z);
    B=A+S.*Z;
return; 
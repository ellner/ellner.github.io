X=load('BradfordIrvine.txt');
H=X(:,2); D=X(:,3); 
LH=sqrt(H); 
C=polyfit(LH,D,2)
xvals=sqrt(0:20); 
yhat=polyval(C,xvals);
plot(LH,D,'+',xvals,yhat);

xlabel('sqrt(Habitat Score)','Fontsize',14); 
ylabel('Decline Rate','Fontsize',14);
title('Data from Bradford and Irvine (2000)','FontSize',14);
text(10,0.2,'y= -0.1274 -0.0201x','Fontsize',14);



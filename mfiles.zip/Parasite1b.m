% Parasite load in me and my poor assistant

% vectors to hold the output
me=zeros(31,1); 
assist=zeros(31,1); me=assist; 

% initial values. NOTE: vector entry 1 is time=0! 
	
for t=1:31;
	assist(t)=120*(1.2^t);
	me(t)=400*(1.1^t);
end;

plot(0:30,log(me),'-s',0:30,log(assist),'-h'); 



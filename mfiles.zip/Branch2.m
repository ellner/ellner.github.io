% solve geometric growth model and plot the results

% set the initial population size
initsize=10

% create matrix to hold results sizes and store initial size 
popsize=initsize; 

% create variable to hold the current population size
popnow=initsize;

% calculate population sizes and append to popsize
for i=1:50;
    if(popnow<250);
    	popnow=popnow*2;
    elseif (popnow<500);
        popnow=popnow*1.5;
    else;
        popnow=popnow*0.95;
    end;
    popsize=[popsize;popnow];
end;

% to plot we need to know how many values are in popsize
[r,c]=size(popsize);
xvals=(1:r)-1;
plot(xvals, log10(popsize),'-o');

xlabel('Generation','Fontsize',16); 
ylabel('Population size','Fontsize',16);
title('Limited growth model','Fontsize',18);

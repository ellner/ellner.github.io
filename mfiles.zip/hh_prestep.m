ninc = 10;
t0 = 0;
t1 = 6;
tstep = 0.01;
ts = [t0:tstep:t1]';
steps = length(ts);
ms = zeros(steps,ninc);
hs = zeros(steps,ninc);
mhs = zeros(steps,ninc);
ina = zeros(steps,ninc);
inad = zeros(1,ninc);

for i = 1:ninc
v0 = -100+10*i;
mi0 = mi(v0+100);
ni0 = ni(v0+100);
hi0 = hi(v0+100);

    v1 = 50;
    vi(i) = v0;
    mi1 = mi(150);
    hi1 = hi(150);
    mt1 = mt(150);
    ht1 = ht(150);

    hvi(i) = hi0;
    
    for j = 1:steps
        ms(j,i) = mi1 + (mi0 - mi1)*exp(-ts(j)/mt1);
        hs(j,i) = hi1 + (hi0 - hi1)*exp(-ts(j)/ht1);
    end;
    
    mhs(:,i) = ms(:,i).^3.*hs(:,i);
    ina(:,i) = gna*mhs(:,i)*(v1-vna);

    gvna(:,i) = ina(:,i)/(v1-vna);

end;
figure;
subplot(2,1,1)
hold on;
for i = 1:ninc
plot(ts(1:200),ina(1:200,i))
     end;
gmax = max(gvna);

hipred = gmax/max(gmax)
subplot(2,1,2)
plot(vi,hipred,'ro',vi,hvi)

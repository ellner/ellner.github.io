A=[0 0.0043 0.1132 0; 0.9775 0.9111 0 0; 0 0.0736 0.9534 0 ; 0 0 0.0452 0.9804]; 

% compute lambda and w
[W,D]=eig(A); 
L=diag(D);
j=find(abs(L)==max(abs(L)));
L1=L(j); 
w=W(:,j); 

% initial population vector
xt=[10; 60; 110; 70];  

% vector to hold total population size
N=zeros(51,1); N(1)=sum(xt); 

%matrix to hold proportions in each stage
X=zeros(4,51); X(:,1)=xt/sum(xt); 

% loop over 50 years
for i=2:51;
       xt=A*xt;
       N(i)=sum(xt);
       X(:,i)=xt/sum(xt); 
end;

% plot the population size
subplot(2,2,1);
plot(0:50,N); xlabel('Time (years)'); ylabel('Whales');

% plot the annual growth and compare with long-term rate lambda
subplot(2,2,2);
plot(1:50,N(2:51)./N(1:50),1:50,L1*ones(50,1),'--','LineWidth',2); 
xlabel('Time (years)'); ylabel('Annual Growth lambda(t)');

% plot proportions
subplot(2,2,3);
plot(0:50,X); xlabel('Time (years)'); ylabel('Stage Proportions');

% Show stable proportions w/sum(w) 
wscale=w/sum(w);
text(51,wscale(1),'1');
text(51,wscale(2),'2');
text(55,wscale(3),'3');
text(58,wscale(4),'4');
       

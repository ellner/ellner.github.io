% solves and plots trajectories of the Morris-Lecar equations:

[t,x]=ode23(@ML,[0 800],[-30;0],[],216.9);

plot(x(:,1),x(:,2))
xlabel('V')
ylabel('w')


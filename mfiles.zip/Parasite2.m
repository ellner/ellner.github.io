% Parasite load in me and my poor assistant

% vectors to hold the output
me=400; assist=120;

% current values
me_now=400; assist_now=120; 

while me_now>assist_now; 
	assist_now=1.2*assist_now;
	me_now=1.1*me_now;
	assist=[assist; assist_now];
	me=[me; me_now];
end;

[r,c]=size(me); 
time_values=(1:r)-1;
plot(time_values,log(me),'-s',time_values,log(assist),'-h'); 

[time_values', log(me),log(assist)]



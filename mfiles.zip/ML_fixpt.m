% calculates the fixed point(s) of the Morris-Lecar equations
% (fixed point is where derivatives are zero)
% this uses a multi-dimensional version of Newton's Method
clear

% initial value:
x0=[-60; .01];

[x,fval,exitflag,output,jacob]=fsolve(@ML,x0,[],90);

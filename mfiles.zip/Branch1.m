% solve geometric growth model and plot the results

% set the initial population size
initsize=10

% create matrix to hold results sizes and store initial size 
popsize=initsize; 

% create variable to hold the current population size
popnow=initsize;

% calculate population sizes and append to popsize
while popnow<1000;
    if(popnow<250);
    	popnow=popnow*2;
    else;
        popnow=popnow*1.5;
    end;
    popsize=[popsize;popnow];
end;

% to plot we need to know how many values are in popsize
[r,c]=size(popsize);
xvals=(1:r)-1;
plot(xvals, log10(popsize),'-o');

xlabel('Generation','Fontsize',16); 
ylabel('Population size','Fontsize',16);
title('Geometric growth model','Fontsize',18);

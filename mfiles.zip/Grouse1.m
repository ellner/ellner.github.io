% Adapted sage grouse model: iteration of mean matrix

%Mean transition matrix
A=[0.18 0.6 0.6; .33 0 0; 0 .73 .73];

% find dominant eigenvalue/eigenvector
[W,D]=eig(A); L=diag(D);
j=find(abs(L)==max(abs(L)));
lambda=L(j); w=W(:,j); 

% initial distribution
xt=[430; 140; 430];  
Ngrouse=zeros(101,1); Ngrouse(1)=sum(xt);
for i=1:100;
    xt=A*xt;
    Ngrouse(i+1)=sum(xt);
end; 
plot(0:100,Ngrouse); 
xlabel('Time (years)'); 
ylabel('Projected grouse abundance');
axis([0 100 0 1000]); 
    
    
% Evaluates Morris-Lecar Equations
function f = ML(t,x,I);  %<== use when running ode23
%function f = ML(x,I);     %<== use when running fsolve
 
f=zeros(2,1);
V=x(1);
w=x(2);

% set parameters
V1=-1.2;
V2=18;
V3=2;
V4=30;
g_Ca=4.4;
g_K=8;
g_L=2;
Vk=-84;
VL=-60;
V_Ca=120;
C=20;
phi=0.04;

% Evaluate equations

m_inf=0.5 * (1+tanh((V-V1)/V2));
w_inf=0.5 * (1+tanh((V-V3)/V4));
tau_w=1/cosh((V-V3)/(2*V4));

f(1)=1/C * (-g_Ca * m_inf * (V-V_Ca) - g_K*w*(V-Vk) - g_L*(V-VL)+I);
f(2)=phi*(w_inf-w)/tau_w;

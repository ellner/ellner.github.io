t0 = 0;
v0 = -80;
mi0 = mi(v0+100);
ni0 = ni(v0+100);
hi0 = hi(v0+100);

v1 = 30;
mi1 = mi(v1+100);
ni1 = ni(v1+100);
hi1 = hi(v1+100);

mt1 = mt(v1+100);
nt1 = nt(v1+100);
ht1 = ht(v1+100);


t1 = 5;
v1 = 30;
tstep = 0.01;
ts = [t0:tstep:t1]';
steps = length(ts);



ms = zeros(steps,1);
ns = zeros(steps,1);
hs = zeros(steps,1);

for j = 1:steps
ms(j) = mi1 + (mi0 - mi1)*exp(-ts(j)/mt1);
ns(j) = ni1 + (ni0 - ni1)*exp(-ts(j)/nt1);
hs(j) = hi1 + (hi0 - hi1)*exp(-ts(j)/ht1);
end;

mhs = ms.^3.*hs;
curs = (gna*mhs*(v1-vna)+gk*ns.^4*(v1-vk) + gl*(v1-vl));

figure
plot(ts,ms,ts,hs,ts,mhs,ts,ns,ts,ns.^4)
figure
plot(ts,curs)

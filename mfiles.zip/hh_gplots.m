

mplot = figure;
plot(vg,mi,'b',vg,mt/0.5,'g');
xlabel('v');
ylabel('m_{\infty}, 2*m_{\tau}');

nplot = figure;
plot(vg,ni,'b',vg,nt/6,'g');
xlabel('v');
ylabel('n_{\infty}, n_{\tau}/6');

hplot = figure;
plot(vg,hi,'b',vg,ht/9,'g');
xlabel('v');
ylabel('h_{\infty}, h_{\tau}/9');

ninc = 18;
t0 = 0;
v0 = -90;
mi0 = mi(v0+100);
ni0 = ni(v0+100);
hi0 = hi(v0+100);

t1 = 20;
tstep = 0.01;
ts = [t0:tstep:t1]';
steps = length(ts);

ms = zeros(steps,ninc);
hs = zeros(steps,ninc);
mhs = zeros(steps,ninc);
ina = zeros(steps,ninc);
inad = zeros(1,ninc);

for i = 1:ninc
    v1 = -90+10*i;
    vi(i) = v1;
    mi1 = mi(v1+100);
    hi1 = hi(v1+100);
    mt1 = mt(v1+100);
    ht1 = ht(v1+100);
    mvi(i) = mi1;
    hvi(i) = hi1;
    mvt(i) = mt1;
    hvt(i) = ht1;
    
    for j = 1:steps
        ms(j,i) = mi1 + (mi0 - mi1)*exp(-ts(j)/mt1);
        hs(j,i) = hi1 + (hi0 - hi1)*exp(-ts(j)/ht1);
    end;
    
    mhs(:,i) = ms(:,i).^3.*hs(:,i);
    ina(:,i) = gna*mhs(:,i)*(v1-vna);
    gvna(:,i) = ina(:,i)/(v1-vna);
    inad10(i) = (ina(11,i)/ina(10,i)-1)/tstep;
    htlog = log(gvna(300:500,i));
    htls = polyfit(ts(300:500),htlog,1);
    htpred(i) = -1/htls(1);
end;

gmax = max(gvna);
mipred = (gmax/max(gmax)).^(1/3);
m10 = (gvna(10,:)/max(gmax)).^(1/3);
mtpred = 3*(mipred./m10 - 1)./inad10;


naplot = figure
subplot(3,1,1)
plot(vi,mvi,vi,mipred,'ro');
xlabel('v');
ylabel('m_\infty');
subplot(3,1,2)
plot(vi,mvt,vi,mtpred,'ro');
xlabel('v');
ylabel('\tau_m');
subplot(3,1,3)
plot(vi(4:18),htpred(4:18),'ro',vi(4:18),hvt(4:18));
xlabel('v');
ylabel('\tau_h');


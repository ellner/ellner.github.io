nt = 1000000;
A = [0.98, 0.10, 0; 0.02, 0.7, 0.05; 0, 0.2, 0.95]
sum(A)
     rd = rand(nt,1);
     states = ones(nt+1,1);
     states(1) = 3;
for i=1:nt
     if rd(i) < A(3,states(i))
        states(i+1) = 3;
     elseif rd(i) < A(3,states(i))+A(2,states(i))
        states(i+1) = 2;
     end;
end;
op = (states > 2);  
op_diff = op(1:nt)+2*op(2:nt+1);
it1 = find(op_diff == 2);
it2 = find(op_diff == 1);
ol = min(length(it1),length(it2));

oruns = it2(2:ol) - it1(1:ol-1);
obins = max(oruns)
orunh = histc(oruns,[1:obins])';

cruns = it1(1:ol) - it2(1:ol);
cbins = max(cruns)
crunh = histc(cruns,[1:cbins])';

[va,ea] = eig(A)
[em, im] = max(diag(ea));
vm = va(:,im)
sdist = [sum(states == 1);sum(states == 2);sum(states == 3)]
sratio = sum(vm)*sdist./vm/nt

otime = sum(oruns);
ctime = sum(cruns);

oh = figure;
bar(orunh);
ch = figure; 
bar(crunh);

cho = figure;
for j=1:10
  subplot(10,1,j);plot(op(1+(j-1)*1000:1+j*1000))
  axis([1 1000 -1 2]);
end

  sh = figure;
for j=1:10
 subplot(10,1,j);plot(states(1+(j-1)*1000:1+j*1000)) 
 axis([1 1000 0 4]); 
end 

 logh = figure;
semilogy([1:100],orunh(1:100),'b',[1:100],crunh(1:100),'r');

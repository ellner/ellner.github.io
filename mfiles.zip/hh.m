
function f = hh(t,x)
 
global p;

f = zeros(4,1);
gna = p(1);
gk = p(2);
gl = p(3);
vna = p(4);
vk = p(5);
vl = p(6);
temp = p(7);
cur = p(8);

v = x(1);
m = x(2);
n = x(3);
h = x(4);
 
amv = -(v+35.0)/10.0;
anv = -(v+50.0)/10.0;

am = amv/(exp(amv) - 1);
bm = 4.0*exp(-(v+60.0)/18.0);
an = 0.1*anv/(exp(anv) - 1);
bn = 0.125*exp(-(v+60.0)/80.0);
ah = 0.07*exp(-(v+60.0)/20.0);
bh = 1.0/(1.0+exp(-0.1*(v+30.0)));
phi = exp(log(3.0)*(temp-6.3)/10.0);

f(1) = cur - gna*m^3*h*(v-vna) - gk*n^4*(v-vk) - gl*(v-vl);
f(2) = phi*((1.0-m)*am - m*bm);
f(3) = phi*((1.0-n)*an - n*bn);
f(4) = phi*((1.0-h)*ah - h*bh);

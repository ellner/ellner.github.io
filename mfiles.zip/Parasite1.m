% Parasite load in me and my poor assistant

% vectors to hold the output
me=zeros(31,1); 
assist=zeros(31,1); me=assist; 

% initial values. NOTE: vector entry 1 is time=0! 
assist(1)=120; me(1)=400; 
	
for t=2:31;
	assist(t)=1.2*assist(t-1);
	me(t)=1.1*me(t-1);
end;

plot(0:30,log(me),'-s',0:30,log(assist),'-h'); 



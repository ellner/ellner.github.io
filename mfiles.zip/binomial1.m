trials = 10000;
nt = 100;
p = 0.6;
headsum = zeros(trials,1);
for i = 1:trials
    rd = rand(nt,1);
    heads = (rd < p);
    headsum(i) = sum(heads);
end; 
minh = min(headsum); 
maxh = max(headsum); 
hhist = histc(headsum,[minh:maxh]); 
b = zeros(maxh-minh+1,1); 
gauss = zeros(maxh-minh+1,1); 
for i = minh:maxh 
    b(i-minh+1) = nchoosek(nt,i)*(p)^i*(1-p)^(nt-i); 
    zl = (i-0.5-nt*(p))/sqrt(2*nt*p*(1-p)); 
    zu = (i+0.5-nt*(p))/sqrt(2*nt*p*(1-p)); 
%   gauss(i-minh+1) = (erf(zu) - erf(zl))/2; 
    gauss(i-minh+1) = exp(-(i-nt*(p))^2/(2*nt*p*(1-p)))/sqrt(2*pi*nt*p*(1-p));
end; 

plot([minh:maxh],hhist,'b*',[minh:maxh],b*trials,'ro',[minh:maxh],gauss*trials,'g'); 

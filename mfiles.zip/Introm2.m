X=load('BradfordIrvine.txt');
H=X(:,2); D=X(:,3); 
C=polyfit(H,D,1)
xvals=0:20; 
yhat=polyval(C,xvals);
plot(H,D,'+',xvals,yhat);

xlabel('Habitat Score','Fontsize',14); 
ylabel('Decline Rate','Fontsize',14);
title('Data from Bradford and Irvine (2000)','FontSize',14);
text(10,0.2,'y= -0.1274 -0.0201x','Fontsize',14);



function f=eulot(lambda,la,fa);
    age=0:(length(la)-1);
    y=lambda.^(-(age+1));
    f=sum(y.*la.*fa)-1;
return;

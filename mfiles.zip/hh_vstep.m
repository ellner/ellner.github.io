t0 = 0;
v0 = -80;
mi0 = mi(v0+100);
ni0 = ni(v0+100);
hi0 = hi(v0+100);

t1 = 6;
tstep = 0.01;
ts = [t0:tstep:t1]';
steps = length(ts);

sinc = 7;
ms = zeros(steps,sinc);
ns = zeros(steps,sinc);
hs = zeros(steps,sinc);
curs = zeros(steps,sinc);
gcurs = zeros(steps,sinc);
kcurs = zeros(steps,sinc);

for i=1:sinc
v1 = -50+20*i;
mi1 = mi(v1+100);
ni1 = ni(v1+100);
hi1 = hi(v1+100);

mt1 = mt(v1+100);
nt1 = nt(v1+100);
ht1 = ht(v1+100);

for j = 1:steps
ms(j,i) = mi1 + (mi0 - mi1)*exp(-ts(j)/mt1);
ns(j,i) = ni1 + (ni0 - ni1)*exp(-ts(j)/nt1);
hs(j,i) = hi1 + (hi0 - hi1)*exp(-ts(j)/ht1);
end;

mhs = ms(:,i).^3.*hs(:,i);
ncurs(:,i) = gna*mhs*(v1-vna);
kcurs(:,i) = gk*ns(:,i).^4*(v1-vk);
curs(:,i) = (kcurs(:,i) +ncurs(:,i) + gl*(v1-vl));

end;

 steplot = figure
subplot(3,1,3)
hold on
for i = 1:sinc
plot(ts,ncurs(:,i));
end;
xlabel('t');
ylabel('Na current');

subplot(3,1,2)
hold on
for i = 1:sinc
plot(ts,kcurs(:,i));
end;
xlabel('t');
ylabel('K current');

subplot(3,1,1)
hold on
for i = 1:sinc
plot(ts,curs(:,i));
end;
xlabel('t');
ylabel('Membrane current');

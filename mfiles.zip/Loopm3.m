disp('3 runs of geometric growth with different p(1)')
% disp'ing only 1 item here, so we don't need to build a vector first

p=zeros(5,1);					        
for init=linspace(2,10,3)						
	p(1)=init; 				            
	for n=2:5					        	
	    p(n)=p(n-1)*2; 	  
    end
    for n=1:5
        q=[num2str(n), '  ', num2str(p(n))];	
	    disp(q)				
	end					           
end						            


p = [120;36;0.3;55;-72;-49.4011;6.3;25];

gna = p(1);
gk = p(2);
gl = p(3);
vna = p(4);
vk = p(5);
vl = p(6);
temp = p(7);
cur = p(8);

mt = zeros(200,1);
nt = zeros(200,1);
ht = zeros(200,1);
mi = zeros(200,1);
ni = zeros(200,1);
hi = zeros(200,1);
vg = zeros(200,1);

for j = 1:200

v = j - 99;
vg(j) = v;
amv = -(v+35.0)/10.0;
anv = -(v+50.0)/10.0;

am = amv/(exp(amv) - 1);
bm = 4.0*exp(-(v+60.0)/18.0);
an = 0.1*anv/(exp(anv) - 1);
bn = 0.125*exp(-(v+60.0)/80.0);
ah = 0.07*exp(-(v+60.0)/20.0);
bh = 1.0/(1.0+exp(-0.1*(v+30.0)));
phi = exp(log(3.0)*(temp-6.3)/10.0);

mt(j) = 1/(am+bm);
mi(j) = am/(am+bm);

nt(j) = 1/(an+bn);
ni(j) = an/(an+bn);

ht(j) = 1/(ah+bh);
hi(j) = ah/(ah+bh);

end;


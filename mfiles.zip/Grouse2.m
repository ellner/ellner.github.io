% Adapted sage grouse model: iteration of mean matrix

%Mean transition matrix
A0=[0.18 0.6 0.6; .33 0 0; 0 .73 .73];

% Standard deviations
S=[.04 .13 .13; .09 0 0; 0 .15 .15];

% initial distribution

mins=zeros(1000,1);
Ngrouse=zeros(101,1000); 
for isim=1:1000; 
    xt=[430; 140; 430];  
    Ngrouse(1,isim)=sum(xt);
    for i=1:100;
% Note: new matrix generated at each time, in each simulation
       Z=randn(3,3);
       A=rmatrix(A0,S,Z);
       xt=A*xt;
       Ngrouse(i+1,isim)=sum(xt);
end; 
mins(isim)=min(Ngrouse(1:101,isim));
end;
subplot(2,1,1);
plot(0:100,Ngrouse); 
xlabel('Time (years)'); 
ylabel('Projected grouse abundance');
axis([0 100 0 2000]); 
subplot(2,1,2); hist(log(mins));
    
    